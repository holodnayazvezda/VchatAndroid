package com.example.vchatmessenger;

import static com.example.vchatmessenger.TextWorker.PasswordWorker.checkPassword;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.checkPasswordConfirmation;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.contentError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.lengthError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.matchError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noLowercaseLetter;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noNumberError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noSpecialSymbolError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noUppercaseLetter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    TextView password_condition_text;
    TextView password_confirmation_text;
    EditText password;
    EditText password_confirmation;
    Button button_save;
    ImageButton button_back;

    private void back() {
        if (!password.getText().toString().equals("") || !password_confirmation.getText().toString().equals("")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.cancel_password_change_question);
            builder.setPositiveButton(R.string.yes, (dialogInterface, i) -> finish());
            builder.setNegativeButton(R.string.no, (dialogInterface, i) -> {
                // ничего не делаем диалог закроется автоматически
            });
            builder.create().show();
        } else {
            finish();
        }
    }

    protected void check_button() {
        // проверка на возможность нажатия кнопки
        // если все поля заполнены, то кнопка активна
        button_save.setEnabled(check_password() && check_password_confirmation());
    }

    protected boolean check_password() {
        int res = checkPassword(this.password.getText().toString());
        if (res == lengthError) {
            password_condition_text.setText(R.string.length_password_error);
            return false;
        }
        if (res == noNumberError) {
            password_condition_text.setText(R.string.password_number_error);
            return false;
        }
        if (res == noLowercaseLetter) {
            password_condition_text.setText(R.string.password_lowercase_error);
            return false;
        }
        if (res == noUppercaseLetter) {
            password_condition_text.setText(R.string.password_uppercase_error);
            return false;
        }
        if (res == noSpecialSymbolError) {
            password_condition_text.setText(R.string.special_symbols_error);
            return false;
        }
        if (res == contentError) {
            password_condition_text.setText(R.string.passwords_trash_error);
            return false;
        }
        password_condition_text.setText("");
        return true;
    }

    protected boolean check_password_confirmation() {
        int res = checkPasswordConfirmation(this.password.getText().toString(),
                this.password_confirmation.getText().toString());
        if (res == matchError) {
            password_confirmation_text.setText(R.string.password_confirmation);
            return false;
        }
        password_confirmation_text.setText("");
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.password_creation);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        password_condition_text = findViewById(R.id.password_condition_hint);
        password_confirmation_text = findViewById(R.id.password_confirmation);
        password = findViewById(R.id.password_input);
        password_confirmation = findViewById(R.id.password_confirmation_input);
        button_save = findViewById(R.id.button_next);
        button_back = findViewById(R.id.button_back);
        button_save.setText(R.string.save);
        // восстановить все  данные
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        check_button();  // вызовет check_password() и check_password_confirmation()
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                check_password();
                check_password_confirmation();
                check_button();
            }
        });
        password_confirmation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                check_password();
                check_password_confirmation();
                check_button();
            }
        });
        button_back.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            back();
        });
        button_save.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            Toast.makeText(this, getString(R.string.password_was_changed), Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        back();
    }
}

