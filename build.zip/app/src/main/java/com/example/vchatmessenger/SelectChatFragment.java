package com.example.vchatmessenger;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.vchatmessenger.interfaces.IOnBackPressed;

public class SelectChatFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_select_chat, container, false);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Intent intent = new Intent(requireActivity().getApplicationContext(), ChatActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("scrollToChat", ChatRecyclerAdapter.getScrolledPosition());
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }
}