package com.example.vchatmessenger;

import static com.example.vchatmessenger.TextWorker.SecretKeyWorker.getSecretWords;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class SecretKeyActivity extends AppCompatActivity {
    // TODO: убрать комменты

    Button button_next;
    ImageButton button_back;
    TextView secret_key1;
    TextView secret_key2;
    TextView secret_key3;
    TextView secret_key4;
    TextView secret_key5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secret_key_activity);
        button_back = findViewById(R.id.button_back);
        button_next = findViewById(R.id.button_next);
        secret_key1 = findViewById(R.id.secret_number1);
        secret_key2 = findViewById(R.id.secret_number2);
        secret_key3 = findViewById(R.id.secret_number3);
        secret_key4 = findViewById(R.id.secret_number4);
        secret_key5 = findViewById(R.id.secret_number5);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        TextView[] secret_numbers = {secret_key1, secret_key2, secret_key3, secret_key4, secret_key5};
        ArrayList<String> secret_words = getSecretWords(getApplicationContext());
        // далее в цикле перебираютя элементы массива secret_numbers в каждый ставится случайно сгенерированное пятизначное число
        for (int i = 0; i < secret_numbers.length; i++) {
            secret_numbers[i].setText(secret_words.get(i));
        }
        button_back.setOnClickListener(v -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            finish();
        });
        button_next.setOnClickListener(v -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            Intent intent = new Intent(SecretKeyActivity.this, ChatActivity.class);
            startActivity(intent);
            // Toast.makeText(getApplicationContext(), "В разработке", Toast.LENGTH_SHORT).show();
        });
    }
}
