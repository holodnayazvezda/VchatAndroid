package com.example.vchatmessenger.vchat_elements;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;

public class User {
    private String name;
    private String nickname;
    private String password;  // значительная переменная
    private ArrayList<String> secretWords;
    private ArrayList<baseChat> chats;

    private Drawable image;

    public User(String name, String nickname) {
        this.name = name;
        this.nickname = nickname;
    }

    public User(String name, String nickname, String password, ArrayList<String> secretWords, ArrayList<baseChat> chats, Drawable image) {
        this.name = name;
        this.nickname = nickname;
        this.password = password;
        this.secretWords = secretWords;
        this.chats = chats;
        this.image = image;
    }

    public User(String name, String nickname, String password, ArrayList<baseChat> chats) {
        this.name = name;
        this.nickname = nickname;
        this.password = password;
        this.chats = chats;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public ArrayList<String> getSecretWords() {
        return secretWords;
    }

    public void setSecretWords(ArrayList<String> secretWords) {
        this.secretWords = secretWords;
    }

    public ArrayList<baseChat> getChats() {
        return chats;
    }

    public void setGroups(ArrayList<baseChat> chats) {
        this.chats = chats;
    }

    public void addGroup(baseChat group) {
        chats.add(group);
    }

    public void deleteGroup(baseChat chat) {
        chats.remove(chat);  // подумать насчет корректности выражения
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }
}
