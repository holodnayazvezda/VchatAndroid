package com.example.vchatmessenger.server;

import android.widget.ArrayAdapter;

import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.util.ArrayList;

public class Server {
    private static ArrayList<baseChat> chats = new ArrayList<>();

    public static ArrayList<baseChat> generateGroups() {
        return chats;
    }

    public static void addGroup(baseChat chat) {
        chats.add(chat);
    }

    public static ArrayList<baseChat> getChats() {
        return chats;
    }

    public static ArrayList<Message> generateMessages() {
        ArrayList<Message> msgs = new ArrayList<>();
        for (int i = 0; i < 100; i++) {

            Message tempMessage = new Message(
                    "message " + i,
                    "22:2" + i % 10,
                    null
            );
            switch (i % 3) {
                case 0:
                    tempMessage.setUser(userServer.user1);
                    break;
                case 1:
                    tempMessage.setUser(userServer.user2);
                    break;
                case 2:
                    tempMessage.setUser(userServer.user3);
            }
            msgs.add(tempMessage);
        }
        return msgs;
    }
}
