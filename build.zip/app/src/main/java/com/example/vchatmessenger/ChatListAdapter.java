package com.example.vchatmessenger;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ChatListAdapter extends ArrayAdapter<ChatView> {

    public ChatListAdapter(@NonNull Context context, ChatView[] chats) {
        super(context, R.layout.chat_view_layout, chats);
    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        final ChatView chatView = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.chat_view_layout, null);
        }
        // имя чата будет всегда
        ((TextView) convertView.findViewById(R.id.name_of_chat)).setText(chatView.name_of_chat);
        if (chatView.last_msg.length() > 0) {
            ((TextView) convertView.findViewById(R.id.last_msg)).setText(chatView.last_msg);
        }
        else {
            ((TextView) convertView.findViewById(R.id.last_msg)).setText(R.string.no_messages);
        }
        if (chatView.last_msg_time.length() > 0) {
            ((TextView) convertView.findViewById(R.id.last_msg_time)).setText(chatView.last_msg_time);
        }
        else {
            ((TextView) convertView.findViewById(R.id.last_msg_time)).setText("");
        }
        if (chatView.unread_msg_count > 0) {
            ((TextView) convertView.findViewById(R.id.unread_msg_count)).setText(String.valueOf(chatView.unread_msg_count));
        }
        else {
            ((TextView) convertView.findViewById(R.id.unread_msg_count)).setText("");
        }
        // установить в ImageView стандартную картинку чата (пока)
        ((ImageView) convertView.findViewById(R.id.chat_image)).setImageResource(R.drawable.sample);
        return convertView;
    }
}
