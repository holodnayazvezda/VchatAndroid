package com.example.vchatmessenger;

import static com.example.vchatmessenger.ImageWorker.colors.getRandomColor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.vchat_elements.Channel;
import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.User;
import com.example.vchatmessenger.vchat_elements.baseChat;
import com.github.drjacky.imagepicker.ImagePicker;
import com.github.drjacky.imagepicker.constant.ImageProvider;
import com.google.android.material.imageview.ShapeableImageView;

import org.jetbrains.annotations.NotNull;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.atomic.AtomicReference;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;

public class GroupFragment extends Fragment {

    TextView chatName;
    EditText messageToSend;
    ShapeableImageView group_image;
    ImageButton sendButton;
    ImageButton buttonBack;
    ImageButton searchButton;
    ArrayList<Message> messages;
    RecyclerView list_of_messages;
    ConstraintLayout chatInfo;
    ShapeableImageView chooseImageView;
    long id;
    String nickname;
    private GroupRecyclerAdapter groupRecyclerAdapter;

    protected boolean checkNickname(String s) {
        // проверка никнейма на корректность
        // никнейм должен состоять только из английских букв и цифр
        String regex = "\\w+";  // регулярное выражение для проверки
        if (s.matches(regex)) {
            if (s.length() >= 5) {
                // проверить то что никнейм не сосстоит из одних цифр
                // проврека на то, что никнейм не сосстоит из одних подчеркиваний
                // TODO: сделать проваерку на уникальность никнейма через базу данных
                return !s.matches("[\\d_]+");
            }
        }
        return false;
    }

    protected boolean checkName(String s) {
        return s.length() > 0 && !String.valueOf(s.charAt(0)).equals(" ");
    }

    public baseChat getChatObject(long id) {
        for (baseChat chat : Server.getChats()) {
            if (chat.getId() == id) {
                return chat;
            }
        }
        return null;
    }

    ActivityResultLauncher<Intent> launcher=
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),(ActivityResult result)->{
                if(result.getResultCode()== Activity.RESULT_OK){
                    if (result.getData() != null) {
                        Uri uri = result.getData().getData();
                        InputStream inputStream = null;
                        try {
                            inputStream = requireActivity().getContentResolver().openInputStream(uri);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        if (inputStream != null) {
                            chooseImageView.setImageDrawable(
                                    Drawable.createFromStream(inputStream, uri.toString())
                            );
                        }
                    } else {
                        Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    }
                    // Use the uri to load the image
                }else if(result.getResultCode()==ImagePicker.RESULT_ERROR){
                    Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    // Use ImagePicker.Companion.getError(result.getData()) to show an error
                }
            });

    private void callImagePicker() {
        ImagePicker.Companion.with(requireActivity()).provider(ImageProvider.BOTH).crop().cropSquare().cropOval().createIntentFromDialog(
                new Function1(){
                    public Object invoke(Object var1){
                        this.invoke((Intent)var1);
                        return Unit.INSTANCE;
                    }
                    public void invoke(@NotNull Intent it){
                        Intrinsics.checkNotNullParameter(it,"it");
                        launcher.launch(it);
                    }
                }
        );
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View contentView;
        // TODO: ДОБАВИТЬ ПРОВЕРКУ НА ВЛАДЕЛЬЦА
        if (getArguments().getInt("type") == 1) {
            contentView = inflater.inflate(R.layout.group_fragment, container, false);
        } else {
            contentView = inflater.inflate(R.layout.channel_fragment, container, false);
        }
        chatName = contentView.findViewById(R.id.group_name);  // нельзя было использовать findViewbyid, так как она находилась не в раскладке активности, а в раскладке фрагмента
        searchButton = contentView.findViewById(R.id.search_button);
        buttonBack = contentView.findViewById(R.id.button_back);  // мб поменять id
        chatInfo = contentView.findViewById(R.id.chatInfo);
        try {
            sendButton = contentView.findViewById(R.id.send_button);
            messageToSend = contentView.findViewById(R.id.message_to_send);
        } catch (Exception e) {
            Toast.makeText(getContext(), "channel", Toast.LENGTH_SHORT).show();
        }
        group_image = contentView.findViewById(R.id.group_image);
        // по умолчанию установим sendButton unclickable
        // TODO: восстановить из shared preferences данные messageToSend
        Vibrator vibrator = (Vibrator) requireContext().getSystemService(Context.VIBRATOR_SERVICE);
        // устонавливаем listener на некоторые элементы
        searchButton.setOnClickListener(v -> {
            FragmentManager fm = requireActivity().getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            FragmentSearchMessage fragmentSearchMessage = new FragmentSearchMessage();
            fragmentSearchMessage.setArguments(getArguments());
            ft.replace(R.id.empty_dialog_horizontal, fragmentSearchMessage);
            ft.commit();
        });
        chatInfo.setOnClickListener(v -> {
            baseChat chat = getChatObject(id);
            Dialog dialogCreateGroup = new Dialog(requireActivity());
            dialogCreateGroup.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialogCreateGroup.setCancelable(false);
            EditText nickname_of_channel = null;
            if (chat.getType() == 2) {
                dialogCreateGroup.setContentView(R.layout.dialog_create_new_channel);
                nickname_of_channel = dialogCreateGroup.findViewById(R.id.channel_nickname);
                nickname_of_channel.setText(((Channel) chat).getNickname());
            } else {
                dialogCreateGroup.setContentView(R.layout.dialog_create_group_layout);
            }
            chooseImageView = dialogCreateGroup.findViewById(R.id.chooseImageView);
            if (chat.getType_of_image() == 2) {
                chooseImageView.setImageDrawable(chat.getImage());
            }
            EditText name_of_group = dialogCreateGroup.findViewById(R.id.name_of_channel);
            name_of_group.setText(chat.getName());
            TextView error_message_for_name = dialogCreateGroup.findViewById(R.id.error_message_for_group_name);
            TextView ready = dialogCreateGroup.findViewById(R.id.ready);
            ready.setText(R.string.save);
            TextView cancel = dialogCreateGroup.findViewById(R.id.cancel);
            name_of_group.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                @Override
                public void afterTextChanged(Editable editable) {
                    boolean r = checkName(name_of_group.getText().toString());
                    if (r) {
                        error_message_for_name.setVisibility(View.INVISIBLE);
                    } else {
                        error_message_for_name.setVisibility(View.VISIBLE);
                    }
                }
            });
            EditText finalNickname_of_channel = nickname_of_channel;
            ready.setOnClickListener(z -> {
                if (checkName(name_of_group.getText().toString())) {
                    int type_of_image = 2;
                    group_image.setImageDrawable(chat.getImage());
                    chat.setType_of_image(type_of_image);
                    chatName.setText(name_of_group.getText().toString());
                    chat.setName(chatName.getText().toString());
                    if (chat.getType() == 2) {
                        ((Channel) chat).setNickname(finalNickname_of_channel.getText().toString());
                    }
                    dialogCreateGroup.dismiss();
                } else {
                    vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                }
            });
            chooseImageView.setOnClickListener(z -> {
                callImagePicker();
            });
            chooseImageView.setOnLongClickListener(z -> {
                String[] options = {getString(R.string.yes), getString(R.string.no)};
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle(getString(R.string.delete_ava));
                builder.setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            chooseImageView.setImageDrawable(null);
                            chat.setImage(null);
                            break;
                        case 1:
                            dialog.dismiss();
                    }
                });
                if (chooseImageView.getDrawable() != null) {
                    builder.create().show();
                }
                return false;
            });
            cancel.setOnClickListener(z -> {
                dialogCreateGroup.dismiss();
            });
            dialogCreateGroup.show();
        });
        buttonBack.setOnClickListener(v -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                Intent intent = new Intent(requireActivity(), ChatActivity.class);
                startActivity(intent);
            } else {
                requireActivity().getSupportFragmentManager().
                        beginTransaction().
                        replace(R.id.empty_dialog_horizontal, new SelectChatFragment()).commit();
            }
        });
//      при открытии активности из горизонтальной ориентации можно получить бан
        try {
            assert getArguments() != null;
            id = getArguments().getLong("id");
            nickname = getArguments().getString("nickname");
        } catch (Exception e) {
            e.printStackTrace();
            id = -1;
            nickname = "";
        }
        // работа с данными
        if (id >= 0) {
            baseChat currentChat = getChatObject(id);
            if (currentChat != null) {
                messages = currentChat.getMessages();
                chatName.setText(currentChat.getName());
                // пока хз как выбирать мб так
//                Drawable img = new ImageCreator(Color.GREEN, String.valueOf(chatName.getText().toString().charAt(0)));
//                img.setAlpha(50);
                group_image.setImageDrawable(currentChat.getImage());
            } else {
                messages = new ArrayList<>();
            }
            // работа с адаптером и RecyclerView
            list_of_messages = contentView.findViewById(R.id.fragment_chat);
            list_of_messages.setLayoutManager(new LinearLayoutManager(requireActivity().getApplicationContext(), LinearLayoutManager.VERTICAL, true));
            // перевернуть ArrayList сообщений (messages)
            AtomicReference<ArrayList<Message>> reversedMessages = new AtomicReference<>(new ArrayList<>());
            for (int i = messages.size() - 1; i >= 0; i--) {
                reversedMessages.get().add(messages.get(i));
            }
            messages = reversedMessages.get();
            // записать в адаптер
            assert currentChat != null;
            groupRecyclerAdapter = new GroupRecyclerAdapter(messages, nickname, currentChat.getName(), null);
            list_of_messages.setAdapter(groupRecyclerAdapter);
            if (sendButton != null) {
                sendButton.setOnClickListener(v -> {
                    // подумать, может приделать какую-нибудь анимацию
                    if (messageToSend.getText().toString().length() > 0) {
                        // добавить в конец списка новое сообщение
                        // получить время в формате HH:mm
                        @SuppressLint("SimpleDateFormat") String time = new SimpleDateFormat("HH:mm").format(new Date());
                        messages.add(new Message(String.valueOf(messageToSend.getText()), time, new User("Алексей Макеев", nickname, "dsdsdsd", null)));
                        // перемернуть ArrayList сообщений (messages)
                        ArrayList<Message> reverse = new ArrayList<>();
                        for (int i = messages.size() - 1; i >= 0; i--) {
                            reverse.add(messages.get(i));
                        }
                        messages = reverse;
                        // записать в адаптер
                        groupRecyclerAdapter = new GroupRecyclerAdapter(messages, nickname, currentChat.getName(), null);
                        list_of_messages.setAdapter(groupRecyclerAdapter);
                        // очистить поле ввода
                        messageToSend.setText("");
                    }
                });
            }
        }
        return contentView;
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Bundle data = new Bundle();
        data.putLong("id", id);
        data.putString("nickname", nickname);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), GroupView.class);
                intent.putExtras(data);
                startActivity(intent);
            }
        } else {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), ChatActivity.class);
                intent.putExtras(data);
                startActivity(intent);
            }
        }
    }

}