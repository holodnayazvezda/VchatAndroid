package com.example.vchatmessenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    ImageButton button_back;
    Button button_next;
    EditText nickname;
    TextView error_message_for_nickname;

    protected void check_ability_to_click() {
        boolean result = true;
        // проверка на возможность нажатия кнопки
        // если никнейм есть, то result = true;
        button_next.setEnabled(check_text());
    }


    protected boolean check_text() {
        // проверка на то, что в поле ввода никнейма есть текст
        // если есть текст, то кнопка активна
        boolean result_of_check = false;
        if (nickname.getText().toString().length() < 5) {
            error_message_for_nickname.setText(R.string.error_message_for_nickname);
        }
        else if (false) {
            // TODO: проверить наличие никнейма в базе данных
            error_message_for_nickname.setText(R.string.error_message_for_nickname_not_found);
        }
        else {
            error_message_for_nickname.setText("");
            result_of_check = true;
        }
        return result_of_check;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        // задаем переменные
        button_back = findViewById(R.id.button_back);
        button_next = findViewById(R.id.button_next);
        nickname = findViewById(R.id.nickname);
        error_message_for_nickname = findViewById(R.id.error_message_for_nickname);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // восставновление никнейма из памяти
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        nickname.setText(sharedPreferences.getString("nickname_for_login_activity", ""));
        check_ability_to_click();  // проверка на возможность нажатия кнопки по умолчанию
        check_text();  // проверка на наличие текста в поле ввода никнейма по умолчанию
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                finish();
            }
        });
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // при нажатии на кнопку вибрируем и переходим на следующую активность
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                Intent intent = new Intent(LoginActivity.this, EnterPasswordActivity.class);
                startActivity(intent);
            }
        });
        nickname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                check_ability_to_click();
                check_text();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // сохранение результатов
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("nickname_for_login_activity", nickname.getText().toString());
        editor.apply();
    }
}
