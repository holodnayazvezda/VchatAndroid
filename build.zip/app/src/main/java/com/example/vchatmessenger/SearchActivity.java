package com.example.vchatmessenger;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.userServer;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    ImageButton button_back;
    EditText name_of_chat;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_layout);
        button_back = findViewById(R.id.button_back);
        button_back.setOnClickListener(v -> {
            finish();
        });
        name_of_chat = findViewById(R.id.name_of_chat);
        name_of_chat.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                Bundle bundle = new Bundle();
                bundle.putString("data", name_of_chat.getText().toString());
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                SearchChatFragment searchChatFragment = new SearchChatFragment();
                searchChatFragment.setArguments(bundle);
                ft.replace(R.id.fragment_chat, searchChatFragment);
                ft.commit();
            }
        });
        Bundle bundle = new Bundle();
        bundle.putString("data", name_of_chat.getText().toString());
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        SearchChatFragment searchChatFragment = new SearchChatFragment();
        searchChatFragment.setArguments(bundle);
        ft.replace(R.id.fragment_chat, searchChatFragment);
        ft.commit();
    }
}
