package com.example.vchatmessenger.TextWorker;

public class PasswordWorker {
    public static int ok = 200;
    public static int lengthError = 333;
    public static int noNumberError = 401;
    public static int noLowercaseLetter = 402;
    public static int noUppercaseLetter = 403;
    public static int noSpecialSymbolError = 404;
    public static int contentError = 222;
    public static int matchError = 500;

    public static int checkPassword(String password) {
        // пароль должен соответствовать уловию:
        // 1. длина пароля должна быть не менее 8 символов
        // 2. пароль должен содержать хотя бы одну цифру
        // 3. пароль должен содержать хотя бы одну строчную букву
        // 4. пароль должен содержать хотя бы один спецсимвол
        // 5. пароль должен содержать хотя бы одну заглавную букву
        // 6. пароль не должен содержать ничего другого
        if (password.length() < 8) {
            return lengthError;
        }
        if (!password.matches(".*\\d.*")) {
            return noNumberError;
        }
        if (!password.matches(".*[a-z].*")) {
            return noLowercaseLetter;
        }
        if (!password.matches(".*[A-Z].*")) {
            return noUppercaseLetter;
        }
        if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?].*")) {
            return noSpecialSymbolError;
        }
        if (!password.matches("[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]*")) {
            return contentError;
        }
        return ok;
    }


    public static int checkPasswordConfirmation(String password, String password_confirmation) {
        if (!password.equals(password_confirmation)) {
            return matchError;
        }
        return ok;
    }
}
