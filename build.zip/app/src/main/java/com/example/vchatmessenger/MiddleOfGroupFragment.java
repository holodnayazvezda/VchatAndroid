package com.example.vchatmessenger;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;

public class MiddleOfGroupFragment extends Fragment {

    View contentView;
    RecyclerView list_of_messages;
    ArrayList<Message> messages;
    long id;
    String nickname;
    int scrollTo;

    public baseChat getChatObject(long id) {
        for (baseChat chat : Server.getChats()) {
            if (chat.getId() == id) {
                return chat;
            }
        }
        return null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.middle_of_group_fragment, container, false);
        list_of_messages = contentView.findViewById(R.id.fragment_chat);
        try {
            assert getArguments() != null;
            id = getArguments().getLong("id");
            nickname = getArguments().getString("nickname");
            scrollTo = getArguments().getInt("scrollTo");
        } catch (Exception e) {
            e.printStackTrace();
            id = -1;
            nickname = "";
            scrollTo = -1;
        }
        if (id >= 0) {
            baseChat currentChat = getChatObject(id);
            if (currentChat != null) {
                messages = currentChat.getMessages();
            } else {
                messages = new ArrayList<>();
            }
            list_of_messages.setLayoutManager(new LinearLayoutManager(requireActivity().getApplicationContext(), LinearLayoutManager.VERTICAL, false));
            // записать в адаптер
            assert currentChat != null;
            GroupRecyclerAdapter groupRecyclerAdapter = new GroupRecyclerAdapter(messages, nickname, currentChat.getName(), getArguments().getString("text"));
            list_of_messages.setAdapter(groupRecyclerAdapter);
            // старая работа с позициями, но может пригодится
//            list_of_messages.scrollToPosition(groupRecyclerAdapter.getItemCount() - 1);
//            if (!getArguments().getBoolean("search")) {
//                list_of_messages.scrollToPosition(groupRecyclerAdapter.getItemCount() - 1);
//            } else {
//                if (scrollTo > 0) {
//                    list_of_messages.scrollToPosition(scrollTo - 1);
//                }
//            }
            list_of_messages.scrollToPosition(scrollTo);
        }
        return contentView;
    }
}
