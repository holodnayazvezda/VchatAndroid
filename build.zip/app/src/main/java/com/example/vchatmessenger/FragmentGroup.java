package com.example.vchatmessenger;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.interfaces.IOnBackPressed;
import com.example.vchatmessenger.vchat_elements.Message;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

public class FragmentGroup extends Fragment implements IOnBackPressed {

    static long id;
    boolean search;
    int type = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView;
        FragmentManager fm = requireActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        // получаем данные из getArguments
        try {
            assert getArguments() != null;
            id = getArguments().getLong("id");
            search = getArguments().getBoolean("search");
            type = getArguments().getInt("type");
        } catch (Exception e) {
            id = -1;
            search = false;
            type = -1;
        }
        // TODO: ДОБАВИТЬ ПРОВЕРКУ НА ВЛАДЕЛЬЦА
        if (type == 1) {
            contentView = inflater.inflate(R.layout.group_fragment, container, false);
            if (!search) {
                BottomOfGroupFragment bottomOfGroupFragment = new BottomOfGroupFragment();
                bottomOfGroupFragment.setArguments(getArguments());
                ft.replace(R.id.empty_space_for_bottom, bottomOfGroupFragment);
            } else {
                BottomOfSearchFragment bottomOfSearchFragment = new BottomOfSearchFragment();
                bottomOfSearchFragment.setArguments(getArguments());
                ft.replace(R.id.empty_space_for_bottom, bottomOfSearchFragment);
            }
        } else {
            contentView = inflater.inflate(R.layout.channel_fragment, container, false);
            if (!search) {
                BottomOfChannelFragment bottomOfChannelFragment = new BottomOfChannelFragment();
                bottomOfChannelFragment.setArguments(getArguments());
                ft.replace(R.id.empty_space_for_bottom, bottomOfChannelFragment);
            } else {
                BottomOfSearchFragment bottomOfSearchFragment = new BottomOfSearchFragment();
                bottomOfSearchFragment.setArguments(getArguments());
                ft.replace(R.id.empty_space_for_bottom, bottomOfSearchFragment);
            }
        }
        if (!search) {
            TopOfGroupFragment topOfGroupFragment = new TopOfGroupFragment();
            topOfGroupFragment.setArguments(getArguments());
            MiddleOfGroupFragment middleOfGroupFragment = new MiddleOfGroupFragment();
            middleOfGroupFragment.setArguments(getArguments());
            ft.replace(R.id.empty_space_for_top, topOfGroupFragment);
            ft.replace(R.id.empty_space_for_middle, middleOfGroupFragment);
        } else {
            TopOfSearchFragment topOfSearchFragment = new TopOfSearchFragment();
            topOfSearchFragment.setArguments(getArguments());
            MiddleOfGroupFragment middleOfGroupFragment = new MiddleOfGroupFragment();
            middleOfGroupFragment.setArguments(getArguments());
            ft.replace(R.id.empty_space_for_top, topOfSearchFragment);
            ft.replace(R.id.empty_space_for_middle, middleOfGroupFragment);
        }
        ft.commit();
        return contentView;
    }

    @Override
    public boolean onBackPressed() {
        Fragment fragment = requireActivity().getSupportFragmentManager().findFragmentById(R.id.empty_space_for_top);
        if (fragment != null) {
            ((IOnBackPressed) fragment).onBackPressed();
        }
        return true;
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }
}
