package com.example.vchatmessenger.server;

import android.graphics.drawable.Drawable;

import com.example.vchatmessenger.vchat_elements.User;

import java.util.HashMap;
import java.util.Map;

public class userServer {
    public static Map<Long, Drawable> images = new HashMap<>();
    public static User user1 = new User("Макеев Даниил", "makeevdaniil");
    public static User user2 = new User("Макеев Алексей", "makeevalexey");
    public static User user3 = new User("Федорова Екатерина", "katefedorova");
}
