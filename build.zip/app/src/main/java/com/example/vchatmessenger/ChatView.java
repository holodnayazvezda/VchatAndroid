package com.example.vchatmessenger;

public class ChatView {
    String name_of_chat = "";
    String last_msg = "";
    String last_msg_time = "";
    long unread_msg_count = 0;

    public ChatView(String name_of_chat, String last_msg, String last_msg_time, long unread_msg_count) {
        this.name_of_chat = name_of_chat;
        this.last_msg = last_msg;
        this.last_msg_time = last_msg_time;
        this.unread_msg_count = unread_msg_count;
    }
}
