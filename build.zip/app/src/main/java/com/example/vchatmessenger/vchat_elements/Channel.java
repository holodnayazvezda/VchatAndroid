package com.example.vchatmessenger.vchat_elements;

import android.graphics.drawable.Drawable;
import android.net.Uri;

import java.util.ArrayList;

public class Channel extends baseChat{

    private String nickname;
    private User owner;
    public Channel(String name, String nickname, long id, long unreadMsgCount, ArrayList<Message> messages, Drawable image, User owner, int type_of_image) {
        super(name, unreadMsgCount, messages, id, image, 2, type_of_image);
        this.nickname = nickname;
        this.owner = owner;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }
}
