package com.example.vchatmessenger;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.userServer;
import com.example.vchatmessenger.vchat_elements.Message;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;
import java.util.Objects;

public class GroupRecyclerAdapter extends RecyclerView.Adapter {
    private final ArrayList<Message> messages;
    private final String nickname;
    private final String nameOfChannel;
    private final String nameOfSearchedText;
    private static final int VIEW_TYPE_MESSAGE_SEND = 1;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED = 2;
    private static final int VIEW_TYPE_MESSAGE_RECEIVED_CHANNEL = 3;
    private static int scrolledPosition = 0;

    private static RecyclerView recyclerView;

    public static int getScrolledPosition() {
        return scrolledPosition;
    }

    public static void setScrolledPosition(int scrolledPosition) {
        GroupRecyclerAdapter.scrolledPosition = scrolledPosition;
    }

    public static class SendMessageViewHolder extends RecyclerView.ViewHolder {
        TextView content, date_and_time;
        String nameOfSearchedText;

        public SendMessageViewHolder(View itemView, String nameOfSearchedText) {
            super(itemView);
            content = itemView.findViewById(R.id.content);
            date_and_time = itemView.findViewById(R.id.date_and_time);
            this.nameOfSearchedText = nameOfSearchedText;
        }

        void bind(Message message) {
            int position = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
            if (position <= 2) {
                position = 0;
            }
            setScrolledPosition(position);
            content.setText(message.getContent());
            if (message.getContent() != null && nameOfSearchedText != null) {
                if (message.getContent().toLowerCase().contains(nameOfSearchedText.toLowerCase())) {
                    int start = message.getContent().toLowerCase().indexOf(nameOfSearchedText.toLowerCase());
                    int end = start + nameOfSearchedText.length();
                    SpannableString string = new SpannableString(message.getContent());
                    string.setSpan(new BackgroundColorSpan(Color.argb(125, 132, 255, 1)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    string.setSpan(new RelativeSizeSpan(1.2f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    content.setText(string);
                }
            }
            // возможно стоит использовать объек класса Date
            date_and_time.setText(message.getDateAndTime());
        }
    }

    public static class ReceivedMessageViewHolder extends RecyclerView.ViewHolder {

        private final TextView name, content, date_and_time;
        private final ShapeableImageView image;
        String nameOfSearchedText;


        public ReceivedMessageViewHolder(@NonNull View itemView, String nameOfSearchedText) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            content = itemView.findViewById(R.id.content);
            date_and_time = itemView.findViewById(R.id.date_and_time);
            image = itemView.findViewById(R.id.image);
            this.nameOfSearchedText = nameOfSearchedText;
        }

        void bind(Message message) {
            int position = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
            if (position <= 2) {
                position = 0;
            }
            setScrolledPosition(position);
            name.setText(message.getUser().getName());
            content.setText(message.getContent());
            if (message.getContent() != null && nameOfSearchedText != null) {
                if (message.getContent().toLowerCase().contains(nameOfSearchedText.toLowerCase())) {
                    int start = message.getContent().toLowerCase().indexOf(nameOfSearchedText.toLowerCase());
                    int end = start + nameOfSearchedText.length();
                    SpannableString string = new SpannableString(message.getContent());
                    string.setSpan(new BackgroundColorSpan(Color.argb(150, 132, 255, 1)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    string.setSpan(new RelativeSizeSpan(1.2f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    content.setText(string);
                }
            }
            date_and_time.setText(message.getDateAndTime());
//            image.setImageDrawable(message.getUser().getImage());
            if (Objects.equals(message.getUser(), userServer.user2)) {
                image.setImageResource(R.drawable.ava1);
            } else if (Objects.equals(message.getUser(), userServer.user3)) {
                image.setImageResource(R.drawable.ava2);
            }
        }
    }

    public static class ReceivedMessageFromChannel extends RecyclerView.ViewHolder {

        private final TextView name, content, date_and_time;
        private final String nameOfChat;
        String nameOfSearchedText;


        public ReceivedMessageFromChannel(@NonNull View itemView, String nameOfSearchedText, String nameOfChat) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            content = itemView.findViewById(R.id.content);
            date_and_time = itemView.findViewById(R.id.date_and_time);
            this.nameOfSearchedText = nameOfSearchedText;
            this.nameOfChat = nameOfChat;
        }

        void bind(Message message) {
            int position = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
            if (position <= 2) {
                position = 0;
            }
            setScrolledPosition(position);
            name.setText(nameOfChat);
            content.setText(message.getContent());
            if (message.getContent() != null && nameOfSearchedText != null) {
                if (message.getContent().toLowerCase().contains(nameOfSearchedText.toLowerCase())) {
                    int start = message.getContent().toLowerCase().indexOf(nameOfSearchedText.toLowerCase());
                    int end = start + nameOfSearchedText.length();
                    SpannableString string = new SpannableString(message.getContent());
                    string.setSpan(new BackgroundColorSpan(Color.argb(150, 132, 255, 1)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    string.setSpan(new RelativeSizeSpan(1.2f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    content.setText(string);
                }
            }
            date_and_time.setText(message.getDateAndTime());
        }
    }

    public GroupRecyclerAdapter(ArrayList<Message> messages, String nickname, String nameOfChannel, String nameOfSearchedText) {
        this.messages = messages;
        this.nickname = nickname;
        this.nameOfChannel = nameOfChannel;
        this.nameOfSearchedText = nameOfSearchedText;
    }

    @Override
    public int getItemViewType(int position) {
        Message message = messages.get(position);
        String n = nameOfChannel;
        String n1 = nickname;
        if (nameOfChannel.equals(nickname)) {
            return VIEW_TYPE_MESSAGE_RECEIVED_CHANNEL;
        } else if (message.getUser().getNickname().equals(nickname)) {
            return VIEW_TYPE_MESSAGE_SEND;
        } else {
            return VIEW_TYPE_MESSAGE_RECEIVED;
        }
    }

    // method's implemention
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == VIEW_TYPE_MESSAGE_SEND) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.group_view_layout_from_me, parent, false);
            return new SendMessageViewHolder(view, nameOfSearchedText);
        } else if (viewType == VIEW_TYPE_MESSAGE_RECEIVED) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.group_view_layout_from_others, parent, false);
            return new ReceivedMessageViewHolder(view, nameOfSearchedText);
        } else {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.channel_view_layout_from_others, parent, false);
            return new ReceivedMessageFromChannel(view, nameOfSearchedText, nameOfChannel);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messages.get(position);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_MESSAGE_SEND:
                ((SendMessageViewHolder) holder).bind(message);
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED:
                ((ReceivedMessageViewHolder) holder).bind(message);
                break;
            case VIEW_TYPE_MESSAGE_RECEIVED_CHANNEL:
                ((ReceivedMessageFromChannel) holder).bind(message);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        GroupRecyclerAdapter.recyclerView = recyclerView;
    }
}
