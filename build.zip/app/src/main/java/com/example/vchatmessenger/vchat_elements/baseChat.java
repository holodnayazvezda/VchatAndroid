package com.example.vchatmessenger.vchat_elements;

import android.graphics.drawable.Drawable;
import android.net.Uri;

import java.util.ArrayList;

public class baseChat {
    private String name;
    private long unreadMsgCount;
    private ArrayList<Message> messages;
    private long id;
    private int type;
    private Drawable image;
    private int type_of_image;

    public baseChat(String name, long unreadMsgCount, ArrayList<Message> messages, long id, Drawable image, int type, int type_of_image) {
        this.name = name;
        this.unreadMsgCount = unreadMsgCount;
        this.messages = messages;
        this.id = id;
        this.image = image;
        this.type = type;
        this.type_of_image = type_of_image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUnreadMsgCount() {
        return unreadMsgCount;
    }

    public void setUnreadMsgCount(long unreadMsgCount) {
        this.unreadMsgCount = unreadMsgCount;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public void addMessage(Message message) {
        messages.add(message);
    }

    public Message getLastMessage() {
        try {
            return messages.get(messages.size() - 1);
        } catch (Exception e) {
            return null;
        }
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getType_of_image() {
        return type_of_image;
    }

    public void setType_of_image(int type_of_image) {
        this.type_of_image = type_of_image;
    }
}
