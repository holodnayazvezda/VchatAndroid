package com.example.vchatmessenger;

import static com.example.vchatmessenger.ImageWorker.colors.getRandomColor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.ImageWorker.CreatorImage;
import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.server.userServer;
import com.example.vchatmessenger.vchat_elements.Channel;
import com.example.vchatmessenger.vchat_elements.Group;
import com.example.vchatmessenger.vchat_elements.User;
import com.github.drjacky.imagepicker.ImagePicker;
import com.github.drjacky.imagepicker.constant.ImageProvider;
import com.google.android.material.imageview.ShapeableImageView;
import org.jetbrains.annotations.NotNull;

import java.io.FileNotFoundException;
import java.io.InputStream;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

public class ChatFragment extends Fragment {

    ShapeableImageView chooseImageView;
    static RecyclerView list_of_chats;
    Dialog dialogCreateChat;
    private int scrollToChat;
    // массив стандартных сцветов по типу Color.COLOR_NAME
    ActivityResultLauncher<Intent> launcher=
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),(ActivityResult result)->{
                if(result.getResultCode()==Activity.RESULT_OK) {
                    if (result.getData() != null) {
                        Uri uri = result.getData().getData();
                        Toast.makeText(getContext(), "yes", Toast.LENGTH_SHORT).show();
                        InputStream inputStream = null;
                        try {
                            inputStream = requireActivity().getContentResolver().openInputStream(uri);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        if (inputStream != null) {
                            chooseImageView.setImageDrawable(
                                    Drawable.createFromStream(inputStream, uri.toString())
                            );
                        }
                    } else {
                        Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    }
                    // Use the uri to load the image
                } else if (result.getResultCode()==ImagePicker.RESULT_ERROR) {
                    Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    // Use ImagePicker.Companion.getError(result.getData()) to show an error
                } else {
                    Toast.makeText(getContext(), "fuck", Toast.LENGTH_SHORT).show();
                }
            });


    private void callImagePicker() {
        ImagePicker.Companion.with(requireActivity()).provider(ImageProvider.BOTH).crop().cropSquare().cropOval().createIntentFromDialog(
                new Function1(){
                    public Object invoke(Object var1){
                        this.invoke((Intent)var1);
                        return Unit.INSTANCE;
                    }
                    public void invoke(@NotNull Intent it){
                        Intrinsics.checkNotNullParameter(it,"it");
                        dialogCreateChat.dismiss();
                        launcher.launch(it);
                    }
                }
        );
    }

    protected boolean checkNickname(String s) {
        // проверка никнейма на корректность
        // никнейм должен состоять только из английских букв и цифр
        String regex = "\\w+";  // регулярное выражение для проверки
        if (s.matches(regex)) {
            if (s.length() >= 5) {
                // проверить то что никнейм не сосстоит из одних цифр
                // проврека на то, что никнейм не сосстоит из одних подчеркиваний
                // TODO: сделать проваерку на уникальность никнейма через базу данных
                return !s.matches("[\\d_]+");
            }
        }
        return false;
    }

    protected boolean checkName(String s) {
        return s.length() > 0 && !String.valueOf(s.charAt(0)).equals(" ");
    }

    public long getNewId() {
        if (Server.getChats().size() > 0) {
            return Server.getChats().get(Server.getChats().size() - 1).getId() + 1;
        } else {
            return 1;
        }
    }

    @SuppressLint("ResourceAsColor")
    private void showPicDialog() {
        String[] options = {getString(R.string.group), getString(R.string.channel), getString(R.string.cancel)};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.create));
        builder.setItems(options, (dialog, which) -> {
            Intent intent;
            switch (which) {
                case 0:
                    intent = new Intent(requireActivity(), CreateGroupActivity.class);
                    startActivity(intent);
                    break;
                case 1:
                    intent = new Intent(requireActivity(), CreateChannelActivity.class);
                    startActivity(intent);
                    break;
                case 2:
                    dialog.dismiss();
            }
        });
        builder.create().show();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {
            scrollToChat = getArguments().getInt("scrollToChat");
        } catch (Exception e) {
            scrollToChat = -1;
        }
        User user = userServer.user1;
        user.setGroups(Server.generateGroups());
        // Inflate the layout for this fragment
        View contentView = inflater.inflate(R.layout.fragment_chats, container, false);
        list_of_chats = contentView.findViewById(R.id.list_of_chats);
        Button createChat = contentView.findViewById(R.id.createChat);
        createChat.setOnClickListener(v -> showPicDialog());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(requireActivity().getApplicationContext());
        list_of_chats.setLayoutManager(layoutManager);
        ChatRecyclerAdapter chatRecyclerAdapter = new ChatRecyclerAdapter(user.getChats(), user.getNickname());
        list_of_chats.setAdapter(chatRecyclerAdapter);
        list_of_chats.scrollToPosition(scrollToChat);
        return contentView;
    }
}