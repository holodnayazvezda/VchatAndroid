package com.example.vchatmessenger.vchat_elements;

public class Message {
    private String content;
    private String dateAndTime;

    private User user;

    public Message(String content, String dateAndTime, User user) {
        this.content = content;
        this.dateAndTime = dateAndTime;
        this.user = user;
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getDateAndTime() {
        return dateAndTime;
    }

    public void setDateAndTime(String dateAndTime) {
        this.dateAndTime = dateAndTime;
    }
}
