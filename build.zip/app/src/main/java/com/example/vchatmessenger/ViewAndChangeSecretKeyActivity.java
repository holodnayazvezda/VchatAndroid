package com.example.vchatmessenger;

import static com.example.vchatmessenger.TextWorker.SecretKeyWorker.getSecretWords;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewAndChangeSecretKeyActivity extends AppCompatActivity {

    Button button_regenerate;
    ImageButton button_back;
    TextView secret_key1;
    TextView secret_key2;
    TextView secret_key3;
    TextView secret_key4;
    TextView secret_key5;

    private void setData(ArrayList<String> secretWords) {
        secret_key1.setText(secretWords.get(0));
        secret_key2.setText(secretWords.get(1));
        secret_key3.setText(secretWords.get(2));
        secret_key4.setText(secretWords.get(3));
        secret_key5.setText(secretWords.get(4));
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secret_key_activity);
        button_regenerate = findViewById(R.id.button_next);
        button_back = findViewById(R.id.button_back);
        secret_key1 = findViewById(R.id.secret_number1);
        secret_key2 = findViewById(R.id.secret_number2);
        secret_key3 = findViewById(R.id.secret_number3);
        secret_key4 = findViewById(R.id.secret_number4);
        secret_key5 = findViewById(R.id.secret_number5);
        button_regenerate.setText(R.string.regenerate);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // заполняем рандомными словами
        // TODO: заполняем secret_key 1-5 данными пользователя
        setData(getSecretWords(getApplicationContext()));
        // устанавливаем listener_ы
        button_back.setOnClickListener(v -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            finish();
        });
        button_regenerate.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.regenerate_secret_key_question);
            builder.setPositiveButton(R.string.yes, (dialogInterface, i) -> {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                ArrayList<String> secretWords = getSecretWords(getApplicationContext());
                setData(secretWords);
                // TODO: установить secret_words пользователю
                Toast.makeText(this, getString(R.string.secret_key_regenerated), Toast.LENGTH_SHORT).show();
            });
            builder.setNegativeButton(R.string.no, (dialogInterface, i) -> {
                Toast.makeText(this, getString(R.string.regeneration_of_secret_key_canceled), Toast.LENGTH_SHORT).show();
            });
            builder.create().show();
        });
    }
}
