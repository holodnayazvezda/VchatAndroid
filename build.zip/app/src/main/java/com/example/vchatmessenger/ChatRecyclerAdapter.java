package com.example.vchatmessenger;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.userServer;
import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.baseChat;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

public class ChatRecyclerAdapter extends RecyclerView.Adapter<ChatRecyclerAdapter.ViewHolder> {
    private static ArrayList<baseChat> chats = null;
    private final String user_nickname;
    private static int scrolledPosition = 0;
    private static RecyclerView recyclerView;

    public static int getScrolledPosition() {
        return scrolledPosition;
    }

    public static void setScrolledPosition(int scrolledPosition) {
        ChatRecyclerAdapter.scrolledPosition = scrolledPosition;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final String nickname;
        private final ShapeableImageView chatImage;
        private final TextView nameOfChat;
        private final TextView lastMsg;
        private final TextView lastMsgTime;
        private final TextView unreadMsgCount;

        public ViewHolder(@NonNull View itemView, String nickname) {
            super(itemView);
            this.nickname = nickname;
            chatImage = itemView.findViewById(R.id.chat_image);
            nameOfChat = itemView.findViewById(R.id.name_of_chat);
            lastMsg = itemView.findViewById(R.id.last_msg);
            lastMsgTime = itemView.findViewById(R.id.last_msg_time);
            unreadMsgCount = itemView.findViewById(R.id.unread_msg_count);
        }

        public void setDialog(baseChat chat) {
//            имя чата будет всегда, а остальное - нет
            int position = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition();
            if (position <= 2) {
                position = 0;
            }
            setScrolledPosition(position);
            nameOfChat.setText(chat.getName());
            if (chat.getUnreadMsgCount() > 0) {
                unreadMsgCount.setText(String.valueOf(chat.getUnreadMsgCount()));
            } else {
                unreadMsgCount.setText("");
            }
            if (chat.getLastMessage() != null) {
                Message msg = chat.getLastMessage();
                lastMsg.setText(msg.getContent());
                lastMsgTime.setText(msg.getDateAndTime());
            } else {
                lastMsg.setText(R.string.no_messages);
            }
//            картинки может и не быть тогда не постаится ничего
            chatImage.setImageDrawable(chat.getImage());
            itemView.setOnClickListener(view -> {
                Bundle data = new Bundle();
                data.putLong("id", chat.getId());
                if (chat.getType() == 1) {
                    data.putString("nickname", nickname);
                } else {
                    data.putString("nickname", chat.getName());
                }
                data.putInt("type", chat.getType());
                data.putInt("scrollTo", chat.getMessages().size() - 1);
                if (itemView.getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    Intent intent = new Intent(itemView.getContext(), GroupView.class);
                    intent.putExtras(data);
                    itemView.getContext().startActivity(intent);
                } else {
                    // получить fragment manager из activity
                    FragmentManager fragmentManager = ((FragmentActivity) itemView.getContext()).getSupportFragmentManager();
                    // начать транзакцию
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    // создаем bundle с данными (id)
                    FragmentGroup fragmentGroup = new FragmentGroup();
                    fragmentGroup.setArguments(data);
                    fragmentTransaction.replace(R.id.empty_dialog_horizontal, fragmentGroup);
                    fragmentTransaction.commit();
                }
            });
            itemView.setOnLongClickListener(v -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
                builder.setTitle("Удалить этот чат ?")
                        .setPositiveButton(R.string.yes, (dialogInterface, i) -> {
                            chats.remove(chat);
                            userServer.user1.setGroups(chats);
                            ChatRecyclerAdapter chatRecyclerAdapter = new ChatRecyclerAdapter(userServer.user1.getChats(), userServer.user1.getNickname());
                            ChatFragment.list_of_chats.setAdapter(chatRecyclerAdapter);
                            if (ChatActivity.isStartSearchChat()) {
                                if (chats.size() > 0) {
                                    SearchChatFragment.list_of_chats.setAdapter(chatRecyclerAdapter);
                                } else {
                                    NoChatFoundFragment noChatFoundFragment = new NoChatFoundFragment();
                                    if (itemView.getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                                        ((FragmentActivity) itemView.getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.empty_dialog_vertical, noChatFoundFragment).commit();
                                    } else {
                                        ((FragmentActivity) itemView.getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_chats_layout, noChatFoundFragment).commit();
                                    }
                                }
                            }
                            if (itemView.getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                                if (chat.getId() == FragmentGroup.id && FragmentGroup.id != -1) {
                                    ((FragmentActivity) itemView.getContext()).getSupportFragmentManager().beginTransaction().replace(R.id.empty_dialog_horizontal, new SelectChatFragment()).commit();
                                }
                            }
                        })
                        .setNegativeButton(R.string.no, (dialogInterface, i) -> Toast.makeText(itemView.getContext(), "удаление отменено", Toast.LENGTH_SHORT).show());
                builder.create().show();
                return false;
            });
        }
    }

    public ChatRecyclerAdapter(ArrayList<baseChat> chats, String user_nickname) {
        ChatRecyclerAdapter.chats = chats;
        this.user_nickname = user_nickname;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.chat_view_layout, viewGroup, false);
        return new ViewHolder(view, user_nickname);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.setDialog(chats.get(position));
    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        ChatRecyclerAdapter.recyclerView = recyclerView;
    }
}
