package com.example.vchatmessenger.interfaces;

public interface IOnBackPressed {
    boolean onBackPressed();
}
