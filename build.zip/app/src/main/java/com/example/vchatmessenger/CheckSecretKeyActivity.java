package com.example.vchatmessenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CheckSecretKeyActivity extends AppCompatActivity {

    TextView number1_text;
    EditText number1_input;
    TextView number2_text;
    EditText number2_input;
    TextView number3_text;
    EditText number3_input;

    ImageButton button_back;
    Button button_next;

    TextView warning_text;

    protected boolean check_secret_key() {
        // проверить значения переменных number1_input, number2_input, number3_input на то, что они все состоят из цифр и их длинна строго равна пяти символам
        // если все верно, то вернуть true
        // если хотя бы одно значение не верно, то вернуть false
        return number1_input.getText().toString().length() > 0 && number2_input.getText().toString().length() > 0 && number3_input.getText().toString().length() > 0;
    }

    protected void check_button_and_text() {
        if (check_secret_key()) {
            button_next.setEnabled(true);
            warning_text.setVisibility(View.INVISIBLE);
        }

        else {
            button_next.setEnabled(false);
            warning_text.setVisibility(View.VISIBLE);
        }
    }

    class listener implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

        @Override
        public void afterTextChanged(Editable editable) {
            check_button_and_text();
        }
    }

    protected boolean exists(int[] massive, int count) {
        for (int number: massive) {
            if (count == number) {
                return true;
            }
        }
        return false;
    }

    protected int[] return_number(int[] massive, int index) {
        boolean flag = true;
        while (flag) {
            int count = (int) ((Math.random() * 5) + 0.63);
            if (count == 0) {
                count = 1;
            }
            if (!exists(massive, count)) {
                massive[index] = count;
                flag = false;
            }
        }
        return massive;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_secret_key_activity);
        number1_text = findViewById(R.id.number1_text);
        number1_input = findViewById(R.id.number1_input);
        number2_text = findViewById(R.id.number2_text);
        number2_input = findViewById(R.id.number2_input);
        number3_text = findViewById(R.id.number3_text);
        number3_input = findViewById(R.id.number3_input);
        button_back = findViewById(R.id.button_back);
        button_next = findViewById(R.id.button_next);
        warning_text = findViewById(R.id.warning_text);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        int[] massive = new int[3];
        for (int i = 0; i < massive.length; i++) {
            massive = return_number(massive, i);
        }
        // отсортировать массив massive
        for (int i = 0; i < massive.length; i++) {
            for (int j = 0; j < massive.length; j++) {
                if (massive[i] < massive[j]) {
                    int temp = massive[i];
                    massive[i] = massive[j];
                    massive[j] = temp;
                }
            }
        }
        // установить значения massive в number1_text, number2_text, number3_text
        number1_text.setText(Integer.toString(massive[0]) + ".");
        number2_text.setText(Integer.toString(massive[1]) + ".");
        number3_text.setText(Integer.toString(massive[2]) + ".");
        // восставновление никнейма из памяти
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        number1_input.setText(sharedPreferences.getString("number1_input", ""));
        number2_input.setText(sharedPreferences.getString("number2_input", ""));
        number3_input.setText(sharedPreferences.getString("number3_input", ""));
        check_button_and_text();

        number1_input.addTextChangedListener(new listener());
        number2_input.addTextChangedListener(new listener());
        number3_input.addTextChangedListener(new listener());

        button_back.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            finish();
        });
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CheckSecretKeyActivity.this, PasswordCreation.class);
                intent.putExtra("launch_chat_activity", true);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // сохранение результатов
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("number1_input", number1_input.getText().toString());
        editor.putString("number2_input", number2_input.getText().toString());
        editor.putString("number3_input", number3_input.getText().toString());
        editor.apply();
    }
}
