package com.example.vchatmessenger;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.interfaces.IOnBackPressed;

import java.util.Objects;

public class FragmentSearchMessage extends Fragment {

    ImageButton button_back;
    EditText text_of_message;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_search_message, container, false);
        button_back = contentView.findViewById(R.id.button_back);
        text_of_message = contentView.findViewById(R.id.text_of_message);
        button_back.setOnClickListener(v -> {
            FragmentManager fm = requireActivity().getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            GroupFragment groupFragment = new GroupFragment();
            groupFragment.setArguments(getArguments());
            ft.replace(R.id.empty_dialog_horizontal, groupFragment);
            ft.commit();
        });
        return contentView;
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Bundle data = getArguments();
        data.putBoolean("start_search", true);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (getArguments().getInt("id") >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), GroupView.class);
                intent.putExtras(data);
                startActivity(intent);
            }
        } else {
            if (getArguments().getInt("id") >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), ChatActivity.class);
                intent.putExtras(data);
                startActivity(intent);
            }
        }
    }
}
