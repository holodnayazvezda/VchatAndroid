package com.example.vchatmessenger;

import static com.example.vchatmessenger.ImageWorker.colors.getRandomColor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.ImageWorker.CreatorImage;
import com.example.vchatmessenger.interfaces.IOnBackPressed;
import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.vchat_elements.Channel;
import com.example.vchatmessenger.vchat_elements.baseChat;
import com.github.drjacky.imagepicker.ImagePicker;
import com.github.drjacky.imagepicker.constant.ImageProvider;
import com.google.android.material.imageview.ShapeableImageView;

import org.jetbrains.annotations.NotNull;

import java.io.FileNotFoundException;
import java.io.InputStream;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

public class TopOfGroupFragment extends Fragment implements IOnBackPressed {

    View contentView;
    TextView chatName;
    ImageButton buttonBack;
    ImageButton searchButton;
    ConstraintLayout chatInfo;
    ShapeableImageView group_image, chooseImageView;
    Vibrator vibrator;
    long id;
    String nickname;

    public baseChat getChatObject(long id) {
        for (baseChat chat : Server.getChats()) {
            if (chat.getId() == id) {
                return chat;
            }
        }
        return null;
    }

    protected boolean checkName(String s) {
        return s.length() > 0 && !String.valueOf(s.charAt(0)).equals(" ");
    }

    protected boolean checkNickname(String s) {
        // проверка никнейма на корректность
        // никнейм должен состоять только из английских букв и цифр
        String regex = "\\w+";  // регулярное выражение для проверки
        if (s.matches(regex)) {
            if (s.length() >= 5) {
                // проверить то что никнейм не сосстоит из одних цифр
                // проврека на то, что никнейм не сосстоит из одних подчеркиваний
                // TODO: сделать проваерку на уникальность никнейма через базу данных
                return !s.matches("[\\d_]+");
            }
        }
        return false;
    }

    ActivityResultLauncher<Intent> launcher=
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),(ActivityResult result)->{
                if(result.getResultCode()== Activity.RESULT_OK){
                    if (result.getData() != null) {
                        Uri uri = result.getData().getData();
                        InputStream inputStream = null;
                        try {
                            inputStream = requireActivity().getContentResolver().openInputStream(uri);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        if (inputStream != null) {
                            chooseImageView.setImageDrawable(
                                    Drawable.createFromStream(inputStream, uri.toString())
                            );
                        }
                    } else {
                        Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    }
                    // Use the uri to load the image
                } else if(result.getResultCode()==ImagePicker.RESULT_ERROR){
                    Toast.makeText(getContext(), "Error no data", Toast.LENGTH_SHORT).show();
                    // Use ImagePicker.Companion.getError(result.getData()) to show an error
                }
            });

    private void callImagePicker() {
        ImagePicker.Companion.with(requireActivity()).provider(ImageProvider.BOTH).crop().cropSquare().cropOval().createIntentFromDialog(
                new Function1(){
                    public Object invoke(Object var1){
                        this.invoke((Intent)var1);
                        return Unit.INSTANCE;
                    }
                    public void invoke(@NotNull Intent it){
                        Intrinsics.checkNotNullParameter(it,"it");
                        launcher.launch(it);
                    }
                }
        );
    }

    private void back() {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            Intent intent = new Intent(requireActivity(), ChatActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("scrollToChat", ChatRecyclerAdapter.getScrolledPosition());
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            requireActivity().getSupportFragmentManager().
                    beginTransaction().
                    replace(R.id.empty_dialog_horizontal, new SelectChatFragment()).commit();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.top_of_group_fragment, container, false);
        chatName = contentView.findViewById(R.id.group_name);
        searchButton = contentView.findViewById(R.id.search_button);
        buttonBack = contentView.findViewById(R.id.button_back);
        chatInfo = contentView.findViewById(R.id.chatInfo);
        group_image = contentView.findViewById(R.id.group_image);
        // получаем данные из getArguments()
        try {
            assert getArguments() != null;
            id = getArguments().getLong("id");
            nickname = getArguments().getString("nickname");
        } catch (Exception e) {
            id = -1;
            nickname = "";
        }
        // создаем вибратор
        vibrator = (Vibrator) requireContext().getSystemService(Context.VIBRATOR_SERVICE);
        // устанавливаем listener_ы
        searchButton.setOnClickListener(v -> {
            FragmentManager fm = requireActivity().getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            TopOfSearchFragment topOfSearchFragment = new TopOfSearchFragment();
            Bundle data;
            if (getArguments() != null) {
                data = getArguments();
            } else {
                data = new Bundle();
            }
//            data.remove("scrollTo");
            data.remove("position");
            data.putInt("scrollTo", GroupRecyclerAdapter.getScrolledPosition());
            topOfSearchFragment.setArguments(data);
            BottomOfSearchFragment bottomOfSearchFragment = new BottomOfSearchFragment();
            data.putInt("amount_of_overlaps", -1);
            bottomOfSearchFragment.setArguments(data);
            ft.replace(R.id.empty_space_for_top, topOfSearchFragment);
            ft.replace(R.id.empty_space_for_bottom, bottomOfSearchFragment);
            ft.commit();
        });
        buttonBack.setOnClickListener(v -> {
            back();
        });
        chatInfo.setOnClickListener(v -> {
            // TODO: проверка на владельца
            baseChat chat = getChatObject(id);
            Dialog dialogCreateGroup = new Dialog(requireActivity());
            if (chat.getType() == 1) {
                dialogCreateGroup.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialogCreateGroup.setCancelable(false);
                dialogCreateGroup.setContentView(R.layout.dialog_create_group_layout);
                EditText name_of_group = dialogCreateGroup.findViewById(R.id.name_of_channel);
                name_of_group.setText(chat.getName());
                TextView error_message_for_name = dialogCreateGroup.findViewById(R.id.error_message_for_group_name);
                if (name_of_group.getText().toString().length() > 0) {
                    error_message_for_name.setVisibility(View.INVISIBLE);
                } else {
                    error_message_for_name.setVisibility(View.VISIBLE);
                }
                chooseImageView = dialogCreateGroup.findViewById(R.id.chooseImageView);
                if (chat.getType_of_image() == 2) {
                    chooseImageView.setImageDrawable(chat.getImage());
                }
                TextView ready = dialogCreateGroup.findViewById(R.id.ready);
                ready.setText(R.string.save);
                TextView cancel = dialogCreateGroup.findViewById(R.id.cancel);
                name_of_group.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void afterTextChanged(Editable editable) {
                        boolean r = checkName(name_of_group.getText().toString());
                        if (r) {
                            error_message_for_name.setVisibility(View.INVISIBLE);
                        } else {
                            error_message_for_name.setVisibility(View.VISIBLE);
                        }
                    }
                });
                ready.setOnClickListener(z -> {
                    if (checkName(name_of_group.getText().toString())) {
                        int type_of_image = 2;
                        if (chooseImageView.getDrawable() == null) {
                            CreatorImage creatorImage = new CreatorImage(
                                    getRandomColor(),
                                    String.valueOf(name_of_group.getText().toString().charAt(0))
                            );
                            Bitmap bitmap = creatorImage.createBitmap();
                            chooseImageView.setImageBitmap(bitmap);
                            type_of_image = 1;
                        }
                        group_image.setImageDrawable(chooseImageView.getDrawable());
                        chatName.setText(name_of_group.getText().toString());
                        chat.setType_of_image(type_of_image);
                        chat.setImage(chooseImageView.getDrawable());
                        chat.setName(chatName.getText().toString());
                        dialogCreateGroup.dismiss();
                    } else {
                        vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                    }
                });
                chooseImageView.setOnClickListener(z -> {
                    callImagePicker();
                });
                chooseImageView.setOnLongClickListener(z -> {
                    String[] options = {getString(R.string.yes), getString(R.string.no)};
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(getString(R.string.delete_ava));
                    builder.setItems(options, (dialog, which) -> {
                        switch (which) {
                            case 0:
                                CreatorImage creatorImage = new CreatorImage(
                                        getRandomColor(),
                                        String.valueOf(name_of_group.getText().toString().charAt(0))
                                );
                                Bitmap bitmap = creatorImage.createBitmap();
                                group_image.setImageBitmap(bitmap);
                                chooseImageView.setImageDrawable(null);
                                chat.setImage(group_image.getDrawable());
                                chat.setType_of_image(1);
                                break;
                            case 1:
                                dialog.dismiss();
                        }
                    });
                    if (chooseImageView.getDrawable() != null) {
                        builder.create().show();
                    }
                    return false;
                });
                cancel.setOnClickListener(z -> {
                    dialogCreateGroup.dismiss();
                });
                dialogCreateGroup.show();
            } else {
                dialogCreateGroup.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialogCreateGroup.setCancelable(false);
                dialogCreateGroup.setContentView(R.layout.dialog_create_new_channel);
                EditText name_of_channel = dialogCreateGroup.findViewById(R.id.name_of_channel);
                EditText nickname_of_channel = dialogCreateGroup.findViewById(R.id.channel_nickname);
                name_of_channel.setText(chat.getName());
                nickname_of_channel.setText(((Channel) chat).getNickname());
                TextView error_message = dialogCreateGroup.findViewById(R.id.error_message_for_channel_name);
                if (!checkName(name_of_channel.getText().toString())) {
                    error_message.setText(R.string.error_message_for_name);
                } else if (!checkNickname(nickname_of_channel.getText().toString())) {
                    error_message.setText(R.string.error_message_for_nickname);
                } else {
                    error_message.setText("");
                }
                chooseImageView = dialogCreateGroup.findViewById(R.id.chooseImageView);
                if (chat.getType_of_image() == 2) {
                    chooseImageView.setImageDrawable(chat.getImage());
                }
                TextView ready = dialogCreateGroup.findViewById(R.id.ready);
                ready.setText(R.string.save);
                TextView cancel = dialogCreateGroup.findViewById(R.id.cancel);
                name_of_channel.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void afterTextChanged(Editable editable) {
                        boolean r1 = checkName(name_of_channel.getText().toString());
                        boolean r2 = checkNickname(nickname_of_channel.getText().toString());
                        if (!r1) {
                            error_message.setText(R.string.error_message_for_name);
                        } else if (!r2) {
                            error_message.setText(R.string.error_message_for_nickname);
                        } else {
                            error_message.setText("");
                        }
                    }
                });
                nickname_of_channel.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                    @Override
                    public void afterTextChanged(Editable editable) {
                        boolean r1 = checkName(name_of_channel.getText().toString());
                        boolean r2 = checkNickname(nickname_of_channel.getText().toString());
                        if (!r1) {
                            error_message.setText(R.string.error_message_for_name);
                        } else if (!r2) {
                            error_message.setText(R.string.error_message_for_nickname);
                        } else {
                            error_message.setText("");
                        }
                    }
                });
                ready.setOnClickListener(z -> {
                    if (checkName(name_of_channel.getText().toString()) && checkNickname(nickname_of_channel.getText().toString())) {
                        int type_of_image = 2;
                        if (chooseImageView.getDrawable() == null) {
                            CreatorImage creatorImage = new CreatorImage(
                                    getRandomColor(),
                                    String.valueOf(name_of_channel.getText().toString().charAt(0))
                            );
                            Bitmap bitmap = creatorImage.createBitmap();
                            chooseImageView.setImageBitmap(bitmap);
                            type_of_image = 1;
                        }
                        group_image.setImageDrawable(chooseImageView.getDrawable());
                        chatName.setText(name_of_channel.getText().toString());
                        chat.setType_of_image(type_of_image);
                        chat.setImage(chooseImageView.getDrawable());
                        chat.setName(chatName.getText().toString());
                        ((Channel) chat).setNickname(nickname_of_channel.getText().toString());
                        dialogCreateGroup.dismiss();
                    } else {
                        vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE));
                    }
                });
                chooseImageView.setOnClickListener(z -> {
                    callImagePicker();
                });
                chooseImageView.setOnLongClickListener(z -> {
                    String[] options = {getString(R.string.yes), getString(R.string.no)};
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(getString(R.string.delete_ava));
                    builder.setItems(options, (dialog, which) -> {
                        switch (which) {
                            case 0:
                                CreatorImage creatorImage = new CreatorImage(
                                        getRandomColor(),
                                        String.valueOf(name_of_channel.getText().toString().charAt(0))
                                );
                                Bitmap bitmap = creatorImage.createBitmap();
                                chooseImageView.setImageBitmap(bitmap);
                                chat.setImage(chooseImageView.getDrawable());
                                chat.setType_of_image(1);
                                break;
                            case 1:
                                dialog.dismiss();
                        }
                    });
                    if (chooseImageView.getDrawable() != null) {
                        builder.create().show();
                    }
                    return false;
                });
                cancel.setOnClickListener(z -> {
                    dialogCreateGroup.dismiss();
                });
                dialogCreateGroup.show();
            }
        });
        // работа с данными
        if (id >= 0) {
            baseChat currentChat = getChatObject(id);
            if (currentChat != null) {
                chatName.setText(currentChat.getName());
                group_image.setImageDrawable(currentChat.getImage());
            }
        }
        return contentView;
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Bundle bundle = new Bundle();
        if (getArguments() != null) {
            bundle = getArguments();
        }
        bundle.putInt("scrollTo", GroupRecyclerAdapter.getScrolledPosition());
        bundle.putInt("scrollToChat", ChatRecyclerAdapter.getScrolledPosition());
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), GroupView.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), ChatActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        }
    }

    @Override
    public boolean onBackPressed() {
        back();
        return true;
    }
}
