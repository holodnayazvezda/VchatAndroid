package com.example.vchatmessenger.ImageWorker;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

public class CreatorImage {

    protected String letter;
    protected int color;

    public CreatorImage(int color, String letter) {
        this.color = color;
        this.letter = letter;
    }

    public Bitmap createBitmap() {
        int w = 512, h = 512;
        Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
        Bitmap bmp = Bitmap.createBitmap(w, h, conf); // this creates a MUTABLE bitmap
        Canvas canvas = new Canvas(bmp);
        Paint paint = new Paint();
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPaint(paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(300);
        // нарисовать текст по центру
        Rect bounds = new Rect();
        paint.getTextBounds(letter, 0, letter.length(), bounds);
        int x = w / 2 - bounds.centerX();
        int y = h / 2 - bounds.centerY();
        canvas.drawText(letter, x, y, paint);
        return bmp;
    }
}
