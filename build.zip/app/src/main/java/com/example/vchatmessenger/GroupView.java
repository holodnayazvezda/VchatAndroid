package com.example.vchatmessenger;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.interfaces.IOnBackPressed;

public class GroupView extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_view_layout);
        // получаем Id из intent
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        FragmentGroup fragmentGroup = new FragmentGroup();
        fragmentGroup.setArguments(getIntent().getExtras());
        // внимательно!!!! Если будешь использовать add, то при смене темы будут лаги
        ft.replace(R.id.empty_dialog_horizontal, fragmentGroup);
        ft.commit();
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.empty_space_for_top);
        if (fragment != null) {
            ((IOnBackPressed) fragment).onBackPressed();
        }
    }
}
