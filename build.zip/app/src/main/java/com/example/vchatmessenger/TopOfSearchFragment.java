package com.example.vchatmessenger;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.interfaces.IOnBackPressed;
import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.util.ArrayList;

public class TopOfSearchFragment extends Fragment implements IOnBackPressed {

    View contentView;
    ImageButton button_back;
    EditText message_text;
    Button scroll_up;
    Button scroll_down;
    long id;
    String nickname;
    ArrayList<Message> messages;
    private int currentPosition;
    private int scrollTo;
    private ArrayList<Integer> positions = new ArrayList<>();
    String data;
    int amount_of_overlaps;

    public baseChat getChatObject(long id) {
        for (baseChat chat : Server.getChats()) {
            if (chat.getId() == id) {
                return chat;
            }
        }
        return null;
    }

    private void scroll() {
        amount_of_overlaps = positions.size();
        try {
            scrollTo = positions.get(currentPosition) - 1;
        } catch (Exception e) {
            scrollTo = currentPosition;
        }
        FragmentManager fm = requireActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        MiddleOfGroupFragment middleOfGroupFragment = new MiddleOfGroupFragment();
        Bundle b;
        if (getArguments() != null) {
            b = getArguments();
        } else {
            b = new Bundle();
        }
        b.putInt("scrollTo", scrollTo);
        b.putString("text", data);
        b.putInt("amount_of_overlaps", amount_of_overlaps);
        b.putInt("position", currentPosition);
        b.putBoolean("search", true);
        middleOfGroupFragment.setArguments(b);
        BottomOfSearchFragment bottomOfSearchFragment = new BottomOfSearchFragment();;
        bottomOfSearchFragment.setArguments(b);
        ft.replace(R.id.empty_space_for_bottom, bottomOfSearchFragment);
        ft.replace(R.id.empty_space_for_middle, middleOfGroupFragment);
        ft.commit();
    }

    private void back() {
        Bundle data;
        if (getArguments() != null) {
            data = getArguments();
        } else {
            data = new Bundle();
        }
        data.putString("text", null);
        data.putBoolean("search", false);
        FragmentManager fm = requireActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        TopOfGroupFragment topOfGroupFragment = new TopOfGroupFragment();
        topOfGroupFragment.setArguments(data);
        MiddleOfGroupFragment middleOfGroupFragment = new MiddleOfGroupFragment();
        middleOfGroupFragment.setArguments(data);
        if (data.getInt("type") == 1) {
            BottomOfGroupFragment bottomOfGroupFragment = new BottomOfGroupFragment();
            bottomOfGroupFragment.setArguments(data);
            ft.replace(R.id.empty_space_for_bottom, bottomOfGroupFragment);
        } else {
            BottomOfChannelFragment bottomOfChannelFragment = new BottomOfChannelFragment();
            bottomOfChannelFragment.setArguments(data);
            ft.replace(R.id.empty_space_for_bottom, bottomOfChannelFragment);
        }
        ft.replace(R.id.empty_space_for_top, topOfGroupFragment);
        ft.replace(R.id.empty_space_for_middle, middleOfGroupFragment);
        ft.commit();
    }

    private void initPositions() {
        positions = new ArrayList<>();
        data = message_text.getText().toString();
        for (int i = 0; i < messages.size(); i++) {
            Message message = messages.get(i);
            if (message.getContent().toLowerCase().contains(data.toLowerCase())) {
                positions.add(i + 1);
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.top_of_search_fragment, container, false);
        button_back = contentView.findViewById(R.id.button_back);
        message_text = contentView.findViewById(R.id.message_text);
        scroll_up = contentView.findViewById(R.id.scroll_up);
        scroll_down = contentView.findViewById(R.id.scroll_down);
        final boolean[] loadPositionFromArguments = {true};
        // получаем данные из getArguments()
        assert getArguments() != null;
        id = getArguments().getLong("id");
        nickname = getArguments().getString("nickname");
        currentPosition = getArguments().getInt("position");
        amount_of_overlaps = getArguments().getInt("amount_of_overlaps");
        scrollTo = getArguments().getInt("scrollTo");
        message_text.setText(getArguments().getString("text"));
        // ставим listener_ы
        button_back.setOnClickListener(v -> back());
        if (id >= 0) {
            baseChat currentChat = getChatObject(id);
            if (currentChat != null) {
                messages = currentChat.getMessages();
            } else {
                messages = new ArrayList<>();
            }
            initPositions();
            message_text.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
                @Override
                public void afterTextChanged(Editable editable) {
                    initPositions();
                    if (positions.size() > 0) {
                        if (!loadPositionFromArguments[0] || currentPosition <= 0) {
                            currentPosition = positions.size() - 1;
                        }
                        loadPositionFromArguments[0] = false;
                    } else {
                        currentPosition = messages.size() - 1;
                    }
                    scroll();
                }
            });
            scroll_up.setOnClickListener(v -> {
                if (currentPosition == 0) {
                    currentPosition = positions.size() - 1;
                } else {
                    currentPosition -= 1;
                }
                scroll();
            });
            scroll_down.setOnClickListener(v -> {
                if (currentPosition == positions.size() - 1) {
                    currentPosition = 0;
                } else {
                    currentPosition += 1;
                }
                scroll();
            });
        }
        return contentView;
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Toast.makeText(getContext(), newConfig.colorMode + "", Toast.LENGTH_SHORT).show();
        Bundle b;
        if (getArguments() != null) {
            b = getArguments();
        } else {
            b = new Bundle();
        }
        b.putBoolean("search", true);
        b.putInt("scrollTo", scrollTo);
        b.putString("text", message_text.getText().toString());
        b.putInt("amount_of_overlaps", amount_of_overlaps);
        b.putInt("position", currentPosition);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), GroupView.class);
                intent.putExtras(b);
                startActivity(intent);
            }
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (id >= 0) {
                Intent intent = new Intent(requireActivity().getApplicationContext(), ChatActivity.class);
                intent.putExtras(b);
                startActivity(intent);
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public boolean onBackPressed() {
        back();
        return true;
    }
}
