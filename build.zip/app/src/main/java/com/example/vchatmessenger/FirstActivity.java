package com.example.vchatmessenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class FirstActivity extends AppCompatActivity {
    private TextView hello_title;
    private Spinner language_spinner;
    private Button login_button;
    private Button registration_button;
    private TextView error_message_for_spinner;
    private static int pre_locale = -1;
    Vibrator vibrator;

    protected void check_ability_to_click() {
        login_button.setEnabled(checkSpinner());
        registration_button.setEnabled(checkSpinner());
    }

    protected boolean checkSpinner() {
        // проверка на то, что выбран язык
        return language_spinner.getSelectedItemPosition() != 0;
    }


    protected void setLocale() {
        // установка locale в зависимости от выбранного языка (в language_spinner) 1 - русский, 2 - английский
        if (language_spinner.getSelectedItemPosition() != pre_locale) {
            Locale locale;
            if (language_spinner.getSelectedItemPosition() == 1) {
                locale = new Locale("ru");
            } else if (language_spinner.getSelectedItemPosition() == 2) {
                locale = new Locale("en");
            } else {
                locale = new Locale(
                        getResources().getConfiguration().getLocales().get(0).getLanguage()
                );
            }
            if (!locale.getLanguage().equals(getResources().getConfiguration().getLocales().get(0).getLanguage())) {
                vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
            }
            // установка locale
            Locale.setDefault(locale);
            Configuration configuration = new Configuration();
            configuration.setLocale(locale);
            getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
            pre_locale = language_spinner.getSelectedItemPosition();
            hello_title.setText(getBaseContext().getResources().getString(R.string.welcome_text));
            login_button.setText(getBaseContext().getResources().getString(R.string.login_text));
            registration_button.setText(getBaseContext().getResources().getString(R.string.registration_text));
            error_message_for_spinner.setText(getBaseContext().getResources().getString(R.string.error_message_for_spinner));
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, getBaseContext().getResources().getStringArray(R.array.all_the_countries));
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            language_spinner.setAdapter(adapter);
            language_spinner.setSelection(pre_locale);
        }
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_activity);
        if (pre_locale == -1) {  // при исползовании приложения pre_locale никогда не будет равен -1
            SharedPreferences preferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
            preferences.edit().clear().apply();  // очистка sharedPrefs при первом запуске
        }
        hello_title = findViewById(R.id.hello_title);
        language_spinner = findViewById(R.id.language_spinner);
        error_message_for_spinner = findViewById(R.id.error_message_spinner);
        login_button = findViewById(R.id.login_button);
        registration_button = findViewById(R.id.registration_button);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.all_the_countries));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language_spinner.setAdapter(adapter);
        // восстановление выбранного языка
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        language_spinner.setSelection(sharedPreferences.getInt("language", 0));
        pre_locale = language_spinner.getSelectedItemPosition();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // вызываем check_ability_to_click, чтобы при первом зпуске поле кнопки были неактивны.
        check_ability_to_click();
        // устанавливаем слушатель на спиннер
        language_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // если выбран первый элемент спиннера, то выводим сообщение об ошибке
                if (checkSpinner()) {
                    error_message_for_spinner.setVisibility(View.INVISIBLE);
                } else {
                    error_message_for_spinner.setVisibility(View.VISIBLE);
                }
                setLocale();
                check_ability_to_click();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        login_button.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            Intent intent = new Intent(FirstActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        registration_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                Intent intent = new Intent(FirstActivity.this, RegistrationActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // при паузе сохраняем выбранный язык
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("language", language_spinner.getSelectedItemPosition());
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
}
