//package com.example.vchatmessenger.ImageWorker;
//
//import android.graphics.Canvas;
//
//public class colorImageCreator extends ImageCreator {
//    private int color;
//    private String letter;
//
//    public colorImageCreator(int color, String letter) {
//        this.color = color;
//        this.letter = letter;
//    }
//
//    @Override
//    public void draw(Canvas canvas) {
//        super.mPaint.setColor(color);
//        super.draw(canvas);
//    }
//}
