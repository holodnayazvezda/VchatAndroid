package com.example.vchatmessenger.vchat_elements;

import android.graphics.drawable.Drawable;
import android.net.Uri;

import java.util.ArrayList;

public class Group extends baseChat{
    private User owner;
    public Group(String name, ArrayList<Message> messages, long unreadMsgCount, long id, Drawable image, User owner, int type_of_image) {
        super(name, unreadMsgCount, messages, id, image, 1, type_of_image);
        this.owner = owner;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }
}
