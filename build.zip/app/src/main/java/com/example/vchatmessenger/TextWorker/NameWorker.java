package com.example.vchatmessenger.TextWorker;

public class NameWorker {
    public static boolean checkName(String text) {
        return text.length() != 0;
    }
}
