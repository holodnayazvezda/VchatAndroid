package com.example.vchatmessenger;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.interfaces.IOnBackPressed;

public class ChatActivity extends FragmentActivity {

    Button button_search;

    private long id = -1;
    private boolean startSearchInChat;

    private static boolean startSearchChat;
    private static String nameOfSearchedChat;

    public String getNameOfSearchedChat() {
        return nameOfSearchedChat;
    }

    public void setNameOfSearchedChat(String nameOfSearchedChat) {
        ChatActivity.nameOfSearchedChat = nameOfSearchedChat;
    }

    public static boolean isStartSearchChat() {
        return startSearchChat;
    }

    public static void setStartSearchChat(boolean start_search_chat) {
        ChatActivity.startSearchChat = start_search_chat;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat_layout);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if (startSearchChat) {
            Toast.makeText(this, "yes", Toast.LENGTH_SHORT).show();
            TopOfSearchChatFragment topOfSearchChatFragment = new TopOfSearchChatFragment();
            Bundle bundle = new Bundle();
            if (getIntent().getExtras() != null) {
                bundle = getIntent().getExtras();
            }
            TopOfSearchChatFragment.setCurrentPosition(ChatRecyclerAdapter.getScrolledPosition());
            bundle.putString("name_of_searched_chat", nameOfSearchedChat);
            topOfSearchChatFragment.setArguments(bundle);
            ft.replace(R.id.header_of_chat, topOfSearchChatFragment);
        } else {
            TopChatFragment topChatFragment = new TopChatFragment();
            ft.replace(R.id.header_of_chat, topChatFragment);
        }
        ft.commit();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            try {
                id = getIntent().getExtras().getLong("id");
            } catch (Exception e) {
                id = -1;
            }
            try {
                startSearchInChat = getIntent().getExtras().getBoolean("start_search");
            } catch (Exception e) {
                startSearchInChat = false;
            }
            if (!startSearchInChat) {
                if (id > 0) {
                    FragmentGroup fragmentGroup = new FragmentGroup();
                    fragmentGroup.setArguments(getIntent().getExtras());
                    getSupportFragmentManager().beginTransaction().replace(R.id.empty_dialog_horizontal, fragmentGroup).commit();
                } else {
                    getSupportFragmentManager().beginTransaction().replace(R.id.empty_dialog_horizontal, new SelectChatFragment()).commit();
                }
            } else {
                FragmentSearchMessage fragmentSearchMessage = new FragmentSearchMessage();
                fragmentSearchMessage.setArguments(getIntent().getExtras());
                getSupportFragmentManager().beginTransaction().replace(R.id.empty_dialog_horizontal, fragmentSearchMessage).commit();
            }
            ChatFragment chatFragment = new ChatFragment();
            chatFragment.setArguments(getIntent().getExtras());
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_chats_layout, chatFragment).commit();
        } else {
            fm = getSupportFragmentManager();
            ft = fm.beginTransaction();
            ChatFragment chatFragment = new ChatFragment();
            chatFragment.setArguments(getIntent().getExtras());
            ft.replace(R.id.empty_dialog_vertical, chatFragment);
            ft.commit();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Intent intent = new Intent(ChatActivity.this, ChatActivity.class);
            FragmentManager fm = getSupportFragmentManager();
            Fragment fragment = fm.findFragmentById(R.id.empty_dialog_horizontal);
            Bundle bundle = new Bundle();
            if (fragment != null) {
                if (fragment.getArguments() != null) {
                    bundle = fragment.getArguments();
                }
            }
            bundle.putInt("scrollToChat", ChatRecyclerAdapter.getScrolledPosition());
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.header_of_chat);
        if (fragment != null) {
            ((IOnBackPressed) fragment).onBackPressed();
        } else {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }
    }
}
