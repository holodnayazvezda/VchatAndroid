package com.example.vchatmessenger;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

public class UserActivityNicknameViewFragment extends Fragment {

    View contentView;
    TextView nicknameText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.user_activity_nickname_view_fragment, container, false);
        nicknameText = contentView.findViewById(R.id.nickname_text);
        //  заполняем фейковыми данными:
        nicknameText.setText("Makeev");
        contentView.setOnClickListener(v -> {
            UserActivity.setNicknameOnChange(true);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nickname_fragment_placeholder, new UserActivityNicknameChangeFragment()).commit();
        });
        return contentView;
    }
}
