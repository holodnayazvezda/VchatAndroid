package com.example.vchatmessenger;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.server.Server;
import com.example.vchatmessenger.vchat_elements.Message;
import com.example.vchatmessenger.vchat_elements.User;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BottomOfGroupFragment extends Fragment {

    View contentView;
    EditText messageToSend;
    ImageButton sendButton;
    long id;
    String nickname;
    ArrayList<Message> messages;

    public baseChat getChatObject(long id) {
        for (baseChat chat : Server.getChats()) {
            if (chat.getId() == id) {
                return chat;
            }
        }
        return null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.bottom_of_group_fragment, container, false);
        sendButton = contentView.findViewById(R.id.send_button);
        messageToSend = contentView.findViewById(R.id.message_to_send);
        try {
            assert getArguments() != null;
            id = getArguments().getLong("id");
            nickname = getArguments().getString("nickname");
        } catch (Exception e) {
            e.printStackTrace();
            id = -1;
            nickname = "";
        }
        if (id >= 0) {
            baseChat currentChat = getChatObject(id);
            if (currentChat != null) {
                messages = currentChat.getMessages();
            } else {
                messages = new ArrayList<>();
            }
            sendButton.setOnClickListener(v -> {
                // подумать, может приделать какую-нибудь анимацию
                if (messageToSend.getText().toString().length() > 0) {
                    // добавить в конец списка новое сообщение
                    // получить время в формате HH:mm
                    @SuppressLint("SimpleDateFormat") String time = new SimpleDateFormat("HH:mm").format(new Date());
                    messages.add(new Message(String.valueOf(messageToSend.getText()), time, new User("Алексей Макеев", nickname, "dsdsdsd", null)));
                    // перемернуть ArrayList сообщений (messages)
                    currentChat.setMessages(messages);
                    FragmentManager fm = requireActivity().getSupportFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    MiddleOfGroupFragment middleOfGroupFragment = new MiddleOfGroupFragment();
                    Bundle bundle;
                    if (getArguments() != null) {
                        bundle = getArguments();
                    } else {
                        bundle = new Bundle();
                    }
                    bundle.putInt("scrollTo", 100);
                    middleOfGroupFragment.setArguments(getArguments());
                    ft.replace(R.id.empty_space_for_middle, middleOfGroupFragment);
                    ft.commit();
                    messageToSend.setText("");
                }
            });
        }
        return contentView;
    }
}
