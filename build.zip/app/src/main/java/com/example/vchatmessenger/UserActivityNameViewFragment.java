package com.example.vchatmessenger;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class UserActivityNameViewFragment extends Fragment {

    View contentView;
    TextView usernameText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.user_activity_name_view_fragment, container, false);
        usernameText = contentView.findViewById(R.id.username_text);
        // заполняем фековыми данными:
        usernameText.setText("Даниил");
        contentView.setOnClickListener(v -> {
            UserActivity.setNameOnChange(true);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(
                    R.id.name_fragment_placeholder, new UserActivtyNameChangeFragment()
            ).commit();
        });
        return contentView;
    }
}
