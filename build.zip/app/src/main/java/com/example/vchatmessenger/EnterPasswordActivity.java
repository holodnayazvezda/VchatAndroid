package com.example.vchatmessenger;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EnterPasswordActivity extends AppCompatActivity {

    EditText password;
    TextView password_recovery;
    TextView wrong_password;
    ImageButton button_back;
    Button button_next;


    protected boolean check_password() {
        // TODO: соедениться с вервером, чтоббы проверить пароль
        // пока просто возвращаем true; если длинна больше 8 символов
        return password.getText().toString().length() >= 8;
    }

    protected void check_button_and_text() {
        if (check_password()) {
            button_next.setEnabled(true);
            wrong_password.setVisibility(View.INVISIBLE);
        }
        else {
            button_next.setEnabled(false);
            wrong_password.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_password_activity);
        password = findViewById(R.id.password);
        password_recovery = findViewById(R.id.password_recovery);
        wrong_password = findViewById(R.id.wrong_password);
        button_back = findViewById(R.id.button_back);
        button_next = findViewById(R.id.button_next);
        // восставновление никнейма из памяти
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        password.setText(sharedPreferences.getString("password_input", ""));
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        check_button_and_text();

        password_recovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vibrator.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE));
                Intent intent = new Intent(EnterPasswordActivity.this, CheckSecretKeyActivity.class);
                startActivity(intent);
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                check_button_and_text();
            }
        });

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                finish();
            }
        });
        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO: после создания основных чатов запустить ее, а пока - тост
                // запуск основной активности ChatActivity
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                Intent intent = new Intent(EnterPasswordActivity.this, ChatActivity.class);
                startActivity(intent);

            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // сохранение результатов
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("password_input", password.getText().toString());
        editor.apply();
    }
}
