package com.example.vchatmessenger;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import com.github.drjacky.imagepicker.ImagePicker;
import com.github.drjacky.imagepicker.constant.ImageProvider;


import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

public class SelectYourImage extends AppCompatActivity {
    ImageButton buttonBack;
    Button continueButton;
    Button skipButton;
    ImageView imageView;

    protected void launchNextActivity(boolean vibrate) {
        if (vibrate) {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
        }
        Intent intent = new Intent(SelectYourImage.this, SecretKeyActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_your_image);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        buttonBack = findViewById(R.id.button_back);
        continueButton = findViewById(R.id.continue_button);
        skipButton = findViewById(R.id.skip_button);
        imageView = findViewById(R.id.ava);
        // кнопка назад
        buttonBack.setOnClickListener(v -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            finish();
        });
        //  кнопка установик автара
        continueButton.setOnClickListener(v -> showPicDialog());
        // кнопка пропуска аватара
        skipButton.setOnClickListener(v -> {
            launchNextActivity(true);
        });
    }

    @SuppressLint("QueryPermissionsNeeded")
    private void showPicDialog() {
        ImagePicker.Companion.with(this).provider(ImageProvider.BOTH).crop().cropSquare().cropOval().createIntentFromDialog(
                new Function1(){
                    public Object invoke(Object var1){
                        this.invoke((Intent)var1);
                        return Unit.INSTANCE;
                    }
                    public void invoke(@NotNull Intent it){
                        Intrinsics.checkNotNullParameter(it,"it");
                        launcher.launch(it);
                    }
                }
        );
    }


    ActivityResultLauncher<Intent> launcher=
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),(ActivityResult result)->{
                if(result.getResultCode()==RESULT_OK){
                    if (result.getData() != null) {
                        Uri uri = result.getData().getData();
                        try {
                            saveUri(uri);
                        } catch (IOException e) {
                            Toast.makeText(this, "Error of saving croppeed image", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Error no data", Toast.LENGTH_SHORT).show();
                    }
                    // Use the uri to load the image
                }else if(result.getResultCode()==ImagePicker.RESULT_ERROR){
                    Toast.makeText(this, "Error no data", Toast.LENGTH_SHORT).show();
                    // Use ImagePicker.Companion.getError(result.getData()) to show an error
                }
            });

    private void saveUri(Uri uri) throws IOException {
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        InputStream input = this.getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions);
        input.close();
        // сохраняем
        File file = new File(getApplicationContext().getFilesDir(), "image.jpeg");
        try {
            try (FileOutputStream fos = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                Toast.makeText(this, "Saved successfully", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            launchNextActivity(false);
        }
        // проверка того, что изображение действительно сохранилось
        Toast.makeText(this, getApplicationContext().getFilesDir().getAbsolutePath(), Toast.LENGTH_SHORT).show();
        Bitmap newBitmap = BitmapFactory.decodeFile(getApplicationContext().getFilesDir().getAbsolutePath() +  "/image.jpeg");
        imageView.setImageBitmap(newBitmap);
        launchNextActivity(false);
    }
}