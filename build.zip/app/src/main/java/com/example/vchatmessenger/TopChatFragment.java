package com.example.vchatmessenger;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.vchatmessenger.interfaces.IOnBackPressed;
import com.google.android.material.imageview.ShapeableImageView;

public class TopChatFragment extends Fragment implements IOnBackPressed {

    View contentView;
    Button buttonSearch;
    ShapeableImageView buttonUserInfo;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.top_of_chat_fragment, container, false);
        buttonSearch = contentView.findViewById(R.id.button_search);
        buttonUserInfo = contentView.findViewById(R.id.user_info);
        buttonSearch.setOnClickListener(v -> {
            ChatActivity.setStartSearchChat(true);
            FragmentManager fm = requireActivity().getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            TopOfSearchChatFragment topOfSearchChatFragment = new TopOfSearchChatFragment();
            TopOfSearchChatFragment.setPositionsOfChatlistBeforeSearch(ChatRecyclerAdapter.getScrolledPosition());
            ft.replace(R.id.header_of_chat, topOfSearchChatFragment);
            ft.commit();
        });
        buttonUserInfo.setOnClickListener(v -> {
            Intent intent = new Intent(requireActivity(), UserActivity.class);
            startActivity(intent);
        });
        return contentView;
    }

    @Override
    public boolean onBackPressed() {
        Fragment fragment = requireActivity().getSupportFragmentManager().findFragmentById(R.id.empty_dialog_horizontal);
        try {
            ((IOnBackPressed) fragment).onBackPressed();
        } catch (Exception e) {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }
        return true;
    }
}
