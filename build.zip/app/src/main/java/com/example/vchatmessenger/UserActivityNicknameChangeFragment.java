package com.example.vchatmessenger;

import static com.example.vchatmessenger.TextWorker.NicknameWorker.checkNickname;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserActivityNicknameChangeFragment extends Fragment {

    View contentView;
    EditText newNicknameText;
    TextView errorMessageForNickname;
    ImageButton save;
    ImageButton cancel;
    private static String newNickname;

    public static String getNewNickname() {
        return newNickname;
    }

    public static void setNewNickname(String newNickname) {
        UserActivityNicknameChangeFragment.newNickname = newNickname;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        contentView = inflater.inflate(R.layout.user_activity_nickname_change_fragment, container, false);
        newNicknameText = contentView.findViewById(R.id.new_nickname_text);
        errorMessageForNickname = contentView.findViewById(R.id.error_message_for_nickname);
        save = contentView.findViewById(R.id.save);
        cancel = contentView.findViewById(R.id.cancel);
        newNicknameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                if (checkNickname(newNicknameText.getText().toString())) {
                    errorMessageForNickname.setVisibility(View.INVISIBLE);
                } else {
                    errorMessageForNickname.setVisibility(View.VISIBLE);
                }
                setNewNickname(newNicknameText.getText().toString());
            }
        });
        if (getNewNickname() != null) {
            newNicknameText.setText(getNewNickname());
        }
        cancel.setOnClickListener(v -> {
            UserActivity.setNicknameOnChange(false);
            setNewNickname(null);
            requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nickname_fragment_placeholder, new UserActivityNicknameViewFragment()).commit();
        });
        save.setOnClickListener(v -> {
            if (checkNickname(newNicknameText.getText().toString())) {
                UserActivity.setNicknameOnChange(false);
                setNewNickname(null);
                requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nickname_fragment_placeholder, new UserActivityNicknameViewFragment()).commit();
                // TODO: ИЗМЕНИТЬ НИКНЕЙМ ЛОКАЛЬНО
                Toast.makeText(getContext(), getString(R.string.nickname_changed), Toast.LENGTH_SHORT).show();
            }
        });
        return contentView;
    }
}
