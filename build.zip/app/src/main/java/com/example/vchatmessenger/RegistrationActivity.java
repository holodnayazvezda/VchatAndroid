package com.example.vchatmessenger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


public class RegistrationActivity extends AppCompatActivity {

    private Button button_next;
    private ImageButton button_back;
    private EditText name;
    private EditText nickname;
    private TextView error_message_for_nickname;

    protected void check_ability_to_click() {
        // проверка на возможность нажатия кнопки
        // если все поля заполнены (!В том числе name != ''), то кнопка активна иначе неактивна
        button_next.setEnabled(checkNickname() && !name.getText().toString().equals(""));
    }


    protected boolean checkNickname() {
        // проверка никнейма на корректность
        // никнейм должен состоять только из английских букв и цифр
        String s = nickname.getText().toString();  // получаем никнейм
        String regex = "[a-zA-Z0-9_]+";  // регулярное выражение для проверки
        if (s.matches(regex)) {
            if (s.length() >= 5) {
                // проверить то что никнейм не сосстоит из одних цифр
                if (!s.matches("[0-9_]+")) {
                    // проврека на то, что никнейм не сосстоит из одних подчеркиваний
                    // TODO: сделать проваерку на уникальность никнейма через базу данных
                    error_message_for_nickname.setVisibility(View.INVISIBLE);
                    return true;
                }
            }
        }
        error_message_for_nickname.setVisibility(View.VISIBLE);
        return false;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_activity);
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        name = findViewById(R.id.name);
        nickname = findViewById(R.id.nickname);
        error_message_for_nickname = findViewById(R.id.error_message_nickname);
        button_next = findViewById(R.id.button_next);
        button_back = findViewById(R.id.button_back);
        // восстанавливаем данные из sharedPrefs
        SharedPreferences preferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        name.setText(preferences.getString("name", ""));
        nickname.setText(preferences.getString("nickname", ""));
        // устанавливаем слушатель на спиннер

        check_ability_to_click();  // это для того, чтобы при первом запуске кнопка была неактивна

        name.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                check_ability_to_click();
            }
        });

        nickname.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                check_ability_to_click();
            }
        });

        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // при нажатии на кнопку вибрируем и переходим на следующую активность
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                // TODO: СДЕЛАТЬ КОНСТРУКТОР ДЛЯ ПОДКЛЮЧЕНИЯ К СЕРВЕРУ
                Intent intent = new Intent(RegistrationActivity.this, PasswordCreation.class);
                startActivity(intent);
            }
        });

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // сохраняем данные в SharedPreferences
        SharedPreferences preferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("name", name.getText().toString());
        editor.putString("nickname", nickname.getText().toString());
        editor.apply();
    }
}