package com.example.vchatmessenger.TextWorker;

import android.view.View;

public class NicknameWorker {
    public static boolean checkNickname(String text) {
        String regex = "[a-zA-Z0-9_]+";  // регулярное выражение для проверки
        if (text.matches(regex)) {
            if (text.length() >= 5) {
                // TODO: сделать проваерку на уникальность никнейма через базу данных
                return !text.matches("[0-9_]+");
            }
        }
        return false;
    }
}
