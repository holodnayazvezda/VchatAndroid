package com.example.vchatmessenger;

import static com.example.vchatmessenger.TextWorker.PasswordWorker.checkPassword;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.checkPasswordConfirmation;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.contentError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.lengthError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.matchError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noLowercaseLetter;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noNumberError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noSpecialSymbolError;
import static com.example.vchatmessenger.TextWorker.PasswordWorker.noUppercaseLetter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PasswordCreation extends AppCompatActivity {

    TextView password_condition_text;
    TextView password_confirmation_text;
    EditText password;
    EditText password_confirmation;
    Button button_next;
    ImageButton button_back;

    boolean launch_chat_activity;

    protected void check_button() {
        // проверка на возможность нажатия кнопки
        // если все поля заполнены, то кнопка активна
        button_next.setEnabled(check_password() && check_password_confirmation());
    }

    protected boolean check_password() {
        int res = checkPassword(this.password.getText().toString());
        if (res == lengthError) {
            password_condition_text.setText(R.string.length_password_error);
            return false;
        }
        if (res == noNumberError) {
            password_condition_text.setText(R.string.password_number_error);
            return false;
        }
        if (res == noLowercaseLetter) {
            password_condition_text.setText(R.string.password_lowercase_error);
            return false;
        }
        if (res == noUppercaseLetter) {
            password_condition_text.setText(R.string.password_uppercase_error);
            return false;
        }
        if (res == noSpecialSymbolError) {
            password_condition_text.setText(R.string.special_symbols_error);
            return false;
        }
        if (res == contentError) {
            password_condition_text.setText(R.string.passwords_trash_error);
            return false;
        }
        password_condition_text.setText("");
        return true;
    }

    protected boolean check_password_confirmation() {
        int res = checkPasswordConfirmation(this.password.getText().toString(),
                this.password_confirmation.getText().toString());
        if (res == matchError) {
            password_confirmation_text.setText(R.string.password_confirmation);
            return false;
        }
        password_confirmation_text.setText("");
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.password_creation);

        launch_chat_activity = getIntent().getBooleanExtra("launch_chat_activity", false);  // будет true при входе, false при регистрации (т.к. по умолчанию)

        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        password_condition_text = findViewById(R.id.password_condition_hint);
        password_confirmation_text = findViewById(R.id.password_confirmation);
        password = findViewById(R.id.password_input);
        password_confirmation = findViewById(R.id.password_confirmation_input);
        button_next = findViewById(R.id.button_next);
        button_back = findViewById(R.id.button_back);
        // восстановить все  данные
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        if (!launch_chat_activity) {
            password.setText(sharedPreferences.getString("password1", ""));
            password_confirmation.setText(sharedPreferences.getString("password_confirmation1", ""));
        }

        else {
            password.setText(sharedPreferences.getString("password2", ""));
            password_confirmation.setText(sharedPreferences.getString("password_confirmation2", ""));
        }
        check_button();  // вызовет check_password() и check_password_confirmation()
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                check_password();
                check_password_confirmation();
                check_button();
            }
        });
        password_confirmation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                check_password();
                check_password_confirmation();
                check_button();
            }
        });
        button_back.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            finish();
        });
        button_next.setOnClickListener(view -> {
            vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            if (!launch_chat_activity) {
                Intent intent = new Intent(PasswordCreation.this, SelectYourImage.class);
                startActivity(intent);
            } else {
                vibrator.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
                Intent intent = new Intent(PasswordCreation.this, ChatActivity.class);
                startActivity(intent);
                // Toast.makeText(PasswordCreation.this, "В разработке", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // сохранить все введенные данные
        SharedPreferences preferences = getSharedPreferences("sharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        if (!launch_chat_activity) {
            editor.putString("password1", password.getText().toString());
            editor.putString("password_confirmation1", password_confirmation.getText().toString());
        }
        else {
            editor.putString("password2", password.getText().toString());
            editor.putString("password_confirmation2", password_confirmation.getText().toString());
        }
        editor.apply();
    }
}

