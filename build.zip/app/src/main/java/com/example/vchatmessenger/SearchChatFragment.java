package com.example.vchatmessenger;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vchatmessenger.server.userServer;
import com.example.vchatmessenger.vchat_elements.baseChat;

import java.util.ArrayList;

public class SearchChatFragment extends Fragment {

    public static RecyclerView list_of_chats;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        String message = getArguments().getString("data");
        ArrayList<baseChat> chats = userServer.user1.getChats();
        ArrayList<baseChat> selected_chats = new ArrayList<>();
        if (message.length() > 0) {
            for (baseChat chat : chats) {
                if (chat.getName().toLowerCase().contains(message.toLowerCase())) {
                    selected_chats.add(chat);
                }
            }
        } else {
            selected_chats = chats;
        }
        View contentView = inflater.inflate(R.layout.fragment_search_chat, container, false);
        if (selected_chats.size() > 0) {
            list_of_chats = contentView.findViewById(R.id.list_of_chats);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(requireActivity().getApplicationContext());
            list_of_chats.setLayoutManager(layoutManager);
            ChatRecyclerAdapter chatRecyclerAdapter = new ChatRecyclerAdapter(selected_chats, userServer.user1.getNickname());
            list_of_chats.setAdapter(chatRecyclerAdapter);
            list_of_chats.scrollToPosition(TopOfSearchChatFragment.getCurrentPosition());
        } else {
            FragmentManager fm = requireActivity().getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            NoChatFoundFragment noChatFoundFragment = new NoChatFoundFragment();
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                ft.replace(R.id.empty_dialog_vertical, noChatFoundFragment);
            } else {
                ft.replace(R.id.fragment_chats_layout, noChatFoundFragment);
            }
            ft.commit();
        }
        return contentView;
    }
}
